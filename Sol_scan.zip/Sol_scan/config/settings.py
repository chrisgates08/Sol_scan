"""
=============================================================================
 SOLANA MEMECOIN ALPHA BOT — Configuration
=============================================================================
 All thresholds, API endpoints, and environment-driven settings live here.
 Never hardcode secrets — always use .env / environment variables.
=============================================================================
"""

import os
from dataclasses import dataclass, field
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Telegram
# ---------------------------------------------------------------------------
TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID: str   = os.getenv("TELEGRAM_CHAT_ID", "")   # channel / group id

# ---------------------------------------------------------------------------
# Scanner timing
# ---------------------------------------------------------------------------
SCAN_INTERVAL_SECONDS: int = int(os.getenv("SCAN_INTERVAL", "90"))  # 60–120 s
MAX_PAIRS_PER_SCAN: int    = int(os.getenv("MAX_PAIRS_PER_SCAN", "200"))

# ---------------------------------------------------------------------------
# API endpoints
# ---------------------------------------------------------------------------
DEXSCREENER_BASE_URL    = "https://api.dexscreener.com/latest/dex"
RUGCHECK_BASE_URL       = "https://api.rugcheck.xyz/v1"
GOPLUS_BASE_URL         = "https://api.gopluslabs.io/api/v1"
SOLSCAN_BASE_URL        = "https://public-api.solscan.io"

# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
REQUEST_TIMEOUT_SECONDS: int = 15
MAX_CONCURRENT_REQUESTS: int = 10
USER_AGENT = "SolanaAlphaBot/1.0 (+https://github.com/yourbot)"

# ---------------------------------------------------------------------------
# Strategy 1: Early Micro-Cap  (0–48 h)
# ---------------------------------------------------------------------------
@dataclass
class EarlyMicroCapConfig:
    max_pair_age_hours: float       = 48.0
    min_liquidity_usd: float        = 5_000.0
    max_liquidity_usd: float        = 150_000.0   # wider upper bound for flex
    min_fdv_usd: float              = 20_000.0
    max_fdv_usd: float              = 100_000.0
    min_volume_24h_usd: float       = 30_000.0
    min_txns_1h: int                = 50
    min_txns_24h: int               = 100
    require_dex_profile: bool       = True         # DexScreener "Has Profile"

EARLY_MICRO_CAP = EarlyMicroCapConfig()

# ---------------------------------------------------------------------------
# Strategy 2: Mid-Cap Momentum
# ---------------------------------------------------------------------------
@dataclass
class MidCapMomentumConfig:
    min_liquidity_usd: float        = 75_000.0
    max_liquidity_usd: float        = 500_000.0
    min_fdv_usd: float              = 500_000.0
    max_fdv_usd: float              = 5_000_000.0
    min_volume_24h_usd: float       = 200_000.0
    max_volume_24h_usd: float       = 1_500_000.0
    min_txns_24h: int               = 1_000
    min_price_change_1h_pct: float  = 5.0    # % — must be rising
    min_price_change_6h_pct: float  = 10.0   # % — sustained move

MID_CAP_MOMENTUM = MidCapMomentumConfig()

# ---------------------------------------------------------------------------
# Security thresholds
# ---------------------------------------------------------------------------
@dataclass
class SecurityConfig:
    max_top10_holder_pct: float     = 30.0    # top-10 wallets max supply %
    require_lp_locked_or_burned: bool = True
    reject_mint_enabled: bool       = True    # mint authority still active
    reject_honeypot: bool           = True
    reject_unverified: bool         = True    # contract not verified
    min_security_score: int         = 55      # 0–100; below → reject

SECURITY = SecurityConfig()

# ---------------------------------------------------------------------------
# Signal scoring — minimum to send alert
# ---------------------------------------------------------------------------
MIN_SIGNAL_SCORE: int = 70   # 0–100

# ---------------------------------------------------------------------------
# Deduplication / memory
# ---------------------------------------------------------------------------
SEEN_TOKENS_TTL_HOURS: int = 24   # how long to remember a sent alert
USE_REDIS: bool            = os.getenv("USE_REDIS", "false").lower() == "true"
REDIS_URL: str             = os.getenv("REDIS_URL", "redis://localhost:6379/0")

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
LOG_LEVEL: str  = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE: str   = os.getenv("LOG_FILE", "bot.log")

# ---------------------------------------------------------------------------
# Validate critical env vars at startup
# ---------------------------------------------------------------------------
def validate_env() -> None:
    missing = []
    if not TELEGRAM_BOT_TOKEN:
        missing.append("TELEGRAM_BOT_TOKEN")
    if not TELEGRAM_CHAT_ID:
        missing.append("TELEGRAM_CHAT_ID")
    if missing:
        raise EnvironmentError(
            f"Missing required environment variables: {', '.join(missing)}\n"
            "Please check your .env file."
        )
