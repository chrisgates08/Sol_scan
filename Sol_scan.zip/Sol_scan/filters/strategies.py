"""
=============================================================================
 Strategy Filters
=============================================================================
 Two independent filter pipelines.  Each returns (passed: bool, reason: str).
 Designed to be fast (no I/O) — pure in-memory logic.
=============================================================================
"""

from __future__ import annotations

from typing import Tuple, List
from utils.models import TokenPair, Strategy
from config.settings import EARLY_MICRO_CAP as EMC, MID_CAP_MOMENTUM as MCM
from utils.logger import get_logger

log = get_logger(__name__)

FilterResult = Tuple[bool, str]   # (passed, rejection_reason)


# ---------------------------------------------------------------------------
# Strategy 1: Early Micro-Cap
# ---------------------------------------------------------------------------

def apply_early_micro_cap_filter(pair: TokenPair) -> FilterResult:
    """
    Returns (True, 'ok') if the pair qualifies for Early Micro-Cap strategy.
    Returns (False, reason) with a human-readable rejection reason.
    """
    checks: List[FilterResult] = [
        _check_chain(pair),
        _check_age(pair, EMC.max_pair_age_hours),
        _check_liquidity(pair, EMC.min_liquidity_usd, EMC.max_liquidity_usd),
        _check_fdv(pair, EMC.min_fdv_usd, EMC.max_fdv_usd),
        _check_volume_24h(pair, EMC.min_volume_24h_usd),
        _check_txns_early(pair, EMC.min_txns_1h, EMC.min_txns_24h),
        _check_profile(pair, EMC.require_dex_profile),
    ]
    for passed, reason in checks:
        if not passed:
            return False, reason
    return True, "ok"


# ---------------------------------------------------------------------------
# Strategy 2: Mid-Cap Momentum
# ---------------------------------------------------------------------------

def apply_mid_cap_momentum_filter(pair: TokenPair) -> FilterResult:
    """
    Returns (True, 'ok') if the pair qualifies for Mid-Cap Momentum strategy.
    """
    checks: List[FilterResult] = [
        _check_chain(pair),
        _check_liquidity(pair, MCM.min_liquidity_usd, MCM.max_liquidity_usd),
        _check_fdv(pair, MCM.min_fdv_usd, MCM.max_fdv_usd),
        _check_volume_24h(pair, MCM.min_volume_24h_usd),
        _check_volume_cap(pair, MCM.max_volume_24h_usd),
        _check_txns_24h(pair, MCM.min_txns_24h),
        _check_price_momentum(pair, MCM.min_price_change_1h_pct, MCM.min_price_change_6h_pct),
    ]
    for passed, reason in checks:
        if not passed:
            return False, reason
    return True, "ok"


# ---------------------------------------------------------------------------
# Run both strategies and tag the winning one
# ---------------------------------------------------------------------------

def classify_pair(pair: TokenPair) -> Tuple[bool, str]:
    """
    Try EMC first, then MCM. Tags pair.strategy on success.
    Returns (True, strategy_name) or (False, rejection_reason).
    """
    emc_passed, emc_reason = apply_early_micro_cap_filter(pair)
    if emc_passed:
        pair.strategy = Strategy.EARLY_MICRO_CAP
        return True, Strategy.EARLY_MICRO_CAP.value

    mcm_passed, mcm_reason = apply_mid_cap_momentum_filter(pair)
    if mcm_passed:
        pair.strategy = Strategy.MID_CAP_MOMENTUM
        return True, Strategy.MID_CAP_MOMENTUM.value

    # Neither passed — log the more informative reason
    log.debug(
        "Pair %s (%s) rejected — EMC: %s | MCM: %s",
        pair.base_token_symbol, pair.pair_address[:8], emc_reason, mcm_reason,
    )
    return False, f"EMC: {emc_reason} | MCM: {mcm_reason}"


# ---------------------------------------------------------------------------
# Individual check functions (reusable primitives)
# ---------------------------------------------------------------------------

def _check_chain(pair: TokenPair) -> FilterResult:
    if pair.chain_id != "solana":
        return False, f"wrong chain: {pair.chain_id}"
    return True, "ok"


def _check_age(pair: TokenPair, max_hours: float) -> FilterResult:
    if pair.pair_age_hours > max_hours:
        return False, f"too old: {pair.pair_age_hours:.1f}h > {max_hours}h"
    if pair.pair_age_hours == 0:
        return False, "pair_created_at missing"
    return True, "ok"


def _check_liquidity(pair: TokenPair, min_liq: float, max_liq: float) -> FilterResult:
    if pair.liquidity_usd < min_liq:
        return False, f"liquidity too low: ${pair.liquidity_usd:,.0f} < ${min_liq:,.0f}"
    if pair.liquidity_usd > max_liq:
        return False, f"liquidity too high: ${pair.liquidity_usd:,.0f} > ${max_liq:,.0f}"
    return True, "ok"


def _check_fdv(pair: TokenPair, min_fdv: float, max_fdv: float) -> FilterResult:
    if pair.market_cap <= 0:
        return False, "missing FDV/market cap"
    if pair.market_cap < min_fdv:
        return False, f"FDV too low: ${pair.market_cap:,.0f}"
    if pair.market_cap > max_fdv:
        return False, f"FDV too high: ${pair.market_cap:,.0f}"
    return True, "ok"


def _check_volume_24h(pair: TokenPair, min_vol: float) -> FilterResult:
    if pair.volume_24h < min_vol:
        return False, f"volume too low: ${pair.volume_24h:,.0f} < ${min_vol:,.0f}"
    return True, "ok"


def _check_volume_cap(pair: TokenPair, max_vol: float) -> FilterResult:
    if pair.volume_24h > max_vol:
        return False, f"volume too high for MCM: ${pair.volume_24h:,.0f}"
    return True, "ok"


def _check_txns_early(pair: TokenPair, min_1h: int, min_24h: int) -> FilterResult:
    txns_1h  = pair.txns_1h_buys  + pair.txns_1h_sells
    txns_24h = pair.txns_24h_buys + pair.txns_24h_sells
    if txns_1h < min_1h and txns_24h < min_24h:
        return False, f"low activity: {txns_1h} tx/1h, {txns_24h} tx/24h"
    return True, "ok"


def _check_txns_24h(pair: TokenPair, min_txns: int) -> FilterResult:
    txns_24h = pair.txns_24h_buys + pair.txns_24h_sells
    if txns_24h < min_txns:
        return False, f"tx count too low: {txns_24h} < {min_txns}"
    return True, "ok"


def _check_price_momentum(pair: TokenPair, min_1h: float, min_6h: float) -> FilterResult:
    if pair.price_change_1h < min_1h:
        return False, f"1h momentum weak: {pair.price_change_1h:.1f}% < {min_1h}%"
    if pair.price_change_6h < min_6h:
        return False, f"6h momentum weak: {pair.price_change_6h:.1f}% < {min_6h}%"
    return True, "ok"


def _check_profile(pair: TokenPair, required: bool) -> FilterResult:
    if required and not pair.has_profile:
        return False, "no DexScreener profile"
    return True, "ok"
