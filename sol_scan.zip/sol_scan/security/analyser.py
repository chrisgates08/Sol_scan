"""
=============================================================================
 Smart Contract Security Analyser — RugCheck API (authentifié)
=============================================================================
 Endpoint : GET https://api.rugcheck.xyz/v1/tokens/{mint}/report
 Auth     : Header  X-API-KEY: <RUGCHECK_API_KEY>
            Sans clé → tier gratuit très limité (souvent rejeté)

 Obtenir une clé gratuite : https://rugcheck.xyz  → Dashboard → API Key

 Structure de réponse RugCheck :
 {
   "tokenMeta":      { "name": "...", "symbol": "..." },
   "score":          1234,        ← score interne (higher = riskier)
   "score_normalised": 75,        ← 0-100 (optionnel selon version)
   "risks": [
     { "name": "...", "description": "...", "level": "warn"|"danger", "score": 123 }
   ],
   "markets": [
     { "liquidityLocked": true, "lpBurned": false, "lp": {...} }
   ],
   "topHolders":     [ { "address": "...", "pct": 5.2, "insider": false } ],
   "mintAuthority":  null | "address",
   "freezeAuthority": null | "address",
   "rugged":         false
 }

 Score de sécurité interne (0–100) :
   Départ à 100, pénalités appliquées pour chaque flag de risque.

 Comportement si RugCheck est indisponible / sans clé :
   RUGCHECK_SKIP_ON_FAILURE=true  → score neutre 60, pas de rejet dur
   RUGCHECK_SKIP_ON_FAILURE=false → rejet automatique (worst-case)
=============================================================================
"""

from __future__ import annotations

import os
from typing import Optional

from config.settings import RUGCHECK_BASE_URL, RUGCHECK_API_KEY, SECURITY as SEC
from utils.http_client import fetch_json
from utils.logger import get_logger
from utils.models import SecurityReport

log = get_logger(__name__)

# ---------------------------------------------------------------------------
# Comportement si RugCheck est indisponible
# ---------------------------------------------------------------------------
SKIP_ON_RUGCHECK_FAILURE: bool = (
    os.getenv("RUGCHECK_SKIP_ON_FAILURE", "true").lower() != "false"
)

# Header d'authentification RugCheck
def _rugcheck_headers() -> dict:
    """Construit les headers pour l'API RugCheck."""
    headers = {"Accept": "application/json"}
    if RUGCHECK_API_KEY:
        headers["X-API-KEY"] = RUGCHECK_API_KEY
    else:
        log.warning(
            "RUGCHECK_API_KEY non défini — appel sans authentification "
            "(tier gratuit très limité, risque de 401/403)"
        )
    return headers

# ---------------------------------------------------------------------------
# Pénalités de score (départ à 100)
# ---------------------------------------------------------------------------
_PENALTY = {
    "is_mintable":         40,
    "is_honeypot":         50,
    "lp_not_locked":       30,
    "not_verified":        15,
    "freeze_authority":    20,
    "owner_not_renounced": 10,
    "top10_per_10pct":     20,   # par tranche de 10 % au-dessus du seuil
    "danger_warning":      15,   # par flag "danger" RugCheck
    "warn_warning":         5,   # par flag "warn" (après tolérance de 2)
}

# Mots-clés pour détecter les flags dans les libellés RugCheck
_HONEYPOT_KEYWORDS = ("honeypot", "cannot sell", "sell disabled", "transfer locked")
_MINT_KEYWORDS     = ("mint", "mint authority", "mintable")
_FREEZE_KEYWORDS   = ("freeze", "freeze authority")

# Score neutre si API indisponible (mode SKIP)
_NEUTRAL_SCORE = 60


# ---------------------------------------------------------------------------
# Interface publique
# ---------------------------------------------------------------------------

async def analyse_token(token_address: str) -> SecurityReport:
    """
    Retourne un SecurityReport pour l'adresse Solana donnée via RugCheck.
    """
    report = await _analyse_via_rugcheck(token_address)

    if report is None:
        if SKIP_ON_RUGCHECK_FAILURE:
            log.warning(
                "RugCheck indisponible pour %s — rapport neutre (score=%d)",
                token_address[:12], _NEUTRAL_SCORE,
            )
            report = _neutral_report(token_address)
        else:
            log.warning(
                "RugCheck indisponible pour %s — worst-case (token rejeté)",
                token_address[:12],
            )
            report = _worst_case_report(token_address)

    report.security_score = _calculate_score(report)

    log.debug(
        "Sécurité %s | score=%d | mint=%s | lp=%s | hp=%s | top10=%.1f%% | api_ok=%s",
        token_address[:12],
        report.security_score,
        report.is_mintable,
        report.is_lp_locked,
        report.is_honeypot,
        report.top10_holder_pct,
        not report.raw_data.get("_api_failed", False),
    )
    return report


def is_safe_enough(report: SecurityReport) -> bool:
    """
    Grille de rejet dur.
    Si RugCheck était indisponible (mode SKIP), seul le score numérique est vérifié.
    """
    api_failed = report.raw_data.get("_api_failed", False)

    if not api_failed:
        if report.is_honeypot:
            log.debug("Rejeté — honeypot: %s", report.token_address[:12])
            return False

        if report.is_mintable and SEC.reject_mint_enabled:
            log.debug("Rejeté — mint active: %s", report.token_address[:12])
            return False

        if not report.is_lp_locked and SEC.require_lp_locked_or_burned:
            log.debug("Rejeté — LP non verrouillée: %s", report.token_address[:12])
            return False

        if report.top10_holder_pct > SEC.max_top10_holder_pct:
            log.debug(
                "Rejeté — top10=%.1f%% > %.1f%%: %s",
                report.top10_holder_pct, SEC.max_top10_holder_pct,
                report.token_address[:12],
            )
            return False

        if not report.is_verified and SEC.reject_unverified:
            log.debug("Rejeté — non vérifié: %s", report.token_address[:12])
            return False

    if report.security_score < SEC.min_security_score:
        log.debug(
            "Rejeté — score %d < %d: %s",
            report.security_score, SEC.min_security_score,
            report.token_address[:12],
        )
        return False

    return True


# ---------------------------------------------------------------------------
# Analyse RugCheck (avec authentification)
# ---------------------------------------------------------------------------

async def _analyse_via_rugcheck(token_address: str) -> Optional[SecurityReport]:
    """
    GET /v1/tokens/{mint}/report avec header X-API-KEY.
    Retourne None en cas d'erreur ou de données insuffisantes.
    """
    url     = f"{RUGCHECK_BASE_URL}/tokens/{token_address}/report"
    headers = _rugcheck_headers()
    data    = await fetch_json(url, headers=headers)

    if not data:
        log.warning("RugCheck : réponse vide pour %s", token_address[:12])
        return None

    # Réponse d'erreur RugCheck : {"message": "..."} ou {"error": "..."}
    if isinstance(data, dict) and ("error" in data or "message" in data) and "risks" not in data:
        log.warning(
            "RugCheck erreur pour %s : %s",
            token_address[:12],
            data.get("error") or data.get("message", "unknown"),
        )
        return None

    # Vérification minimale : au moins "risks" ou "tokenMeta" doivent être présents
    if "risks" not in data and "tokenMeta" not in data:
        log.warning(
            "RugCheck : données insuffisantes pour %s — clés reçues: %s",
            token_address[:12],
            list(data.keys())[:10],
        )
        return None

    try:
        return _parse_rugcheck_response(token_address, data)
    except Exception as exc:
        log.warning(
            "RugCheck : erreur de parsing pour %s — %s",
            token_address[:12], exc,
        )
        return None


def _parse_rugcheck_response(token_address: str, data: dict) -> SecurityReport:
    """Parse la réponse brute RugCheck en SecurityReport."""
    risks: list[dict] = data.get("risks") or []

    # Textes normalisés pour keyword matching
    risk_names_lower = [r.get("name", "").lower() for r in risks]
    risk_descs_lower = [r.get("description", "").lower() for r in risks]
    all_risk_texts   = risk_names_lower + risk_descs_lower

    # ── Flags critiques ──────────────────────────────────────────────────
    is_honeypot = _any_keyword_match(all_risk_texts, _HONEYPOT_KEYWORDS)

    is_mintable = (
        data.get("mintAuthority") is not None
        or _any_keyword_match(risk_names_lower, _MINT_KEYWORDS)
    )

    freeze_auth = (
        data.get("freezeAuthority") is not None
        or _any_keyword_match(risk_names_lower, _FREEZE_KEYWORDS)
    )

    # ── Liquidité verrouillée / brûlée ───────────────────────────────────
    markets: list[dict] = data.get("markets") or []
    lp_locked = any(
        bool(m.get("liquidityLocked")) or bool(m.get("lpBurned"))
        for m in markets
    )

    # ── Concentration top holders ─────────────────────────────────────────
    top_holders: list[dict] = data.get("topHolders") or []
    top10_pct = sum(
        float(h.get("pct", 0) or 0)
        for h in top_holders[:10]
    )

    # ── Statut de vérification ───────────────────────────────────────────
    is_verified     = (data.get("mintAuthority") is None and data.get("freezeAuthority") is None)
    owner_renounced = data.get("mintAuthority") is None

    # ── Token déjà rugged ? ──────────────────────────────────────────────
    if data.get("rugged", False):
        log.debug("Token %s marqué 'rugged' par RugCheck", token_address[:12])
        is_honeypot = True   # traité comme honeypot

    # ── Avertissements classés par niveau ────────────────────────────────
    danger_warnings = [
        f"[DANGER] {r.get('name', '')}: {r.get('description', '')}"
        for r in risks
        if r.get("level") in ("danger", "critical")
    ]
    warn_warnings = [
        f"[WARN] {r.get('name', '')}: {r.get('description', '')}"
        for r in risks
        if r.get("level") == "warn"
    ]

    return SecurityReport(
        token_address    = token_address,
        is_mintable      = is_mintable,
        is_lp_locked     = lp_locked,
        is_honeypot      = is_honeypot,
        is_verified      = is_verified,
        top10_holder_pct = top10_pct,
        owner_renounced  = owner_renounced,
        freeze_authority = freeze_auth,
        warnings         = (danger_warnings + warn_warnings)[:10],
        raw_data         = data,   # _api_failed absent → appel réussi
    )


# ---------------------------------------------------------------------------
# Calcul du score de sécurité (0–100)
# ---------------------------------------------------------------------------

def _calculate_score(report: SecurityReport) -> int:
    # Rapport neutre → score fixe
    if report.raw_data.get("_api_failed") and report.raw_data.get("_neutral"):
        return _NEUTRAL_SCORE

    score = 100

    if report.is_mintable:          score -= _PENALTY["is_mintable"]
    if report.is_honeypot:          score -= _PENALTY["is_honeypot"]
    if not report.is_lp_locked:     score -= _PENALTY["lp_not_locked"]
    if not report.is_verified:      score -= _PENALTY["not_verified"]
    if report.freeze_authority:     score -= _PENALTY["freeze_authority"]
    if not report.owner_renounced:  score -= _PENALTY["owner_not_renounced"]

    # Pénalité concentration holders
    excess = max(0.0, report.top10_holder_pct - SEC.max_top10_holder_pct)
    score -= int(excess / 10) * _PENALTY["top10_per_10pct"]

    # Pénalités des warnings RugCheck
    danger_count = sum(1 for w in report.warnings if w.startswith("[DANGER]"))
    warn_count   = sum(1 for w in report.warnings if w.startswith("[WARN]"))
    extra_warns  = max(0, warn_count - 2)   # 2 warns tolérés

    score -= danger_count * _PENALTY["danger_warning"]
    score -= extra_warns  * _PENALTY["warn_warning"]

    return max(0, min(100, score))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _any_keyword_match(texts: list[str], keywords: tuple[str, ...]) -> bool:
    return any(kw in text for text in texts for kw in keywords)


def _neutral_report(token_address: str) -> SecurityReport:
    """Rapport neutre si RugCheck indisponible + SKIP=true."""
    return SecurityReport(
        token_address    = token_address,
        is_mintable      = False,
        is_lp_locked     = True,
        is_honeypot      = False,
        is_verified      = True,
        top10_holder_pct = 25.0,
        owner_renounced  = True,
        freeze_authority = False,
        warnings         = ["⚠️ RugCheck indisponible — données de sécurité non vérifiées"],
        raw_data         = {"_api_failed": True, "_neutral": True},
    )


def _worst_case_report(token_address: str) -> SecurityReport:
    """Worst-case si RUGCHECK_SKIP_ON_FAILURE=false."""
    return SecurityReport(
        token_address    = token_address,
        is_mintable      = True,
        is_lp_locked     = False,
        is_honeypot      = True,
        is_verified      = False,
        top10_holder_pct = 100.0,
        owner_renounced  = False,
        freeze_authority = True,
        warnings         = ["[DANGER] API RugCheck inaccessible — worst-case appliqué"],
        raw_data         = {"_api_failed": True, "_neutral": False},
    )
