"""
=============================================================================
 Signal Scoring Engine
=============================================================================
 Produces a 0–100 composite score from six dimensions:

   1. Liquidity Strength      (0–15)
   2. Volume Surge            (0–20)
   3. Transaction Activity    (0–15)
   4. Wallet Distribution     (0–15)
   5. Price Momentum          (0–20)
   6. Age Premium             (0–15)   — earlier = better
   (Security score bonus)     (0–10)   — from SecurityReport

 Total max = 110 → clamped to 100.
 Minimum to alert: MIN_SIGNAL_SCORE (default 70).
=============================================================================
"""

from __future__ import annotations

import math
from typing import Dict

from utils.models import TokenPair, SecurityReport, ScoredToken, Strategy
from config.settings import MIN_SIGNAL_SCORE
from utils.logger import get_logger

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def score_token(pair: TokenPair, security: SecurityReport) -> ScoredToken:
    """
    Compute the full signal score and return a ScoredToken.
    """
    breakdown: Dict[str, float] = {}

    breakdown["liquidity"]    = _score_liquidity(pair)
    breakdown["volume"]       = _score_volume(pair)
    breakdown["transactions"] = _score_transactions(pair)
    breakdown["distribution"] = _score_distribution(security)
    breakdown["momentum"]     = _score_momentum(pair)
    breakdown["age"]          = _score_age(pair)
    breakdown["security"]     = _score_security_bonus(security)

    raw_score    = sum(breakdown.values())
    signal_score = max(0, min(100, int(raw_score)))

    entry = pair.price_usd
    token = ScoredToken(
        pair            = pair,
        security        = security,
        signal_score    = signal_score,
        score_breakdown = {k: round(v, 2) for k, v in breakdown.items()},
        entry_price_usd = entry,
        tp1_usd         = entry * 2.0,
        tp2_usd         = entry * 3.0,
        tp3_usd         = entry * 4.0,
    )

    log.debug(
        "Signal score %s (%s): %d — breakdown: %s",
        pair.base_token_symbol, pair.pair_address[:8],
        signal_score, breakdown,
    )
    return token


def passes_signal_threshold(token: ScoredToken) -> bool:
    return token.signal_score >= MIN_SIGNAL_SCORE


# ---------------------------------------------------------------------------
# Scoring dimensions
# ---------------------------------------------------------------------------

def _score_liquidity(pair: TokenPair) -> float:
    """
    0–15 pts.  Sweet spot for early tokens: $5k–$50k.
    Mid-cap: $75k–$200k range preferred.
    """
    liq = pair.liquidity_usd
    if liq <= 0:
        return 0.0
    if pair.strategy == Strategy.EARLY_MICRO_CAP:
        # log curve: peaks around $30k
        return min(15.0, 15.0 * (math.log10(liq + 1) - 3) / 2) if liq >= 1_000 else 0.0
    else:
        # Mid-cap: linear within target band
        return min(15.0, 15.0 * (liq / 150_000))


def _score_volume(pair: TokenPair) -> float:
    """
    0–20 pts.  Volume/Liquidity ratio is the key signal.
    A ratio > 5x in 24h is extremely bullish.
    """
    if pair.liquidity_usd <= 0 or pair.volume_24h <= 0:
        return 0.0
    ratio = pair.volume_24h / pair.liquidity_usd
    # ratio 0→10+; scale 0→20 pts (cap at ratio=10)
    return min(20.0, 20.0 * min(ratio, 10.0) / 10.0)


def _score_transactions(pair: TokenPair) -> float:
    """
    0–15 pts.  Activity per hour is a leading indicator.
    """
    txns_1h  = pair.txns_1h_buys  + pair.txns_1h_sells
    txns_24h = pair.txns_24h_buys + pair.txns_24h_sells

    # Buy/sell ratio (more buys = bullish)
    if (pair.txns_1h_buys + pair.txns_1h_sells) > 0:
        buy_ratio = pair.txns_1h_buys / (pair.txns_1h_buys + pair.txns_1h_sells)
    else:
        buy_ratio = 0.5

    activity_score = min(10.0, 10.0 * math.log10(txns_24h + 1) / 4)
    sentiment_bonus = (buy_ratio - 0.5) * 10   # +5 max for pure buys
    return max(0.0, min(15.0, activity_score + sentiment_bonus))


def _score_distribution(security: SecurityReport) -> float:
    """
    0–15 pts.  Penalise whale concentration heavily.
    """
    pct = security.top10_holder_pct
    if pct >= 80:
        return 0.0
    if pct >= 50:
        return 5.0
    if pct >= 30:
        return 10.0
    return 15.0


def _score_momentum(pair: TokenPair) -> float:
    """
    0–20 pts.  Reward strong, sustained upward price action.
    Penalise negative momentum.
    """
    h1  = pair.price_change_1h
    h6  = pair.price_change_6h
    h24 = pair.price_change_24h

    def _normalise(pct: float, cap: float = 100.0) -> float:
        """Map -∞..+cap to 0..1."""
        return max(0.0, min(1.0, (pct + cap / 2) / cap))

    score = (
        _normalise(h1,  cap=50)  * 8  +   # recent move weighted most
        _normalise(h6,  cap=100) * 7  +
        _normalise(h24, cap=200) * 5
    )
    return max(0.0, min(20.0, score))


def _score_age(pair: TokenPair) -> float:
    """
    0–15 pts.  Earlier = better (more runway).
    0–6h = 15, 6–12h = 12, 12–24h = 8, 24–48h = 4, >48h = 0.
    """
    age = pair.pair_age_hours
    if age <= 6:   return 15.0
    if age <= 12:  return 12.0
    if age <= 24:  return 8.0
    if age <= 48:  return 4.0
    return 0.0


def _score_security_bonus(security: SecurityReport) -> float:
    """
    0–10 pts bonus from security score (0–100 maps to 0–10 pts).
    Tokens with high safety get a small boost to final score.
    """
    return security.security_score / 10.0
