"""
=============================================================================
 DexScreener Scanner
=============================================================================
 Fetches Solana token pairs from DexScreener and normalises them into
 TokenPair objects.  Designed for async, high-frequency polling.
=============================================================================
"""

from __future__ import annotations

import asyncio
import time
from typing import List, Optional

from config.settings import DEXSCREENER_BASE_URL, MAX_PAIRS_PER_SCAN
from utils.http_client import fetch_json
from utils.logger import get_logger
from utils.models import TokenPair

log = get_logger(__name__)

# DexScreener search endpoints
_SEARCH_URL    = f"{DEXSCREENER_BASE_URL}/search"
_PAIRS_URL     = f"{DEXSCREENER_BASE_URL}/pairs/solana"
_TOKEN_URL     = f"{DEXSCREENER_BASE_URL}/tokens"

# Trending / latest endpoints
_LATEST_URL    = f"{DEXSCREENER_BASE_URL}/pairs/solana"

# Query terms that surface new/trending Solana memecoins
_SEARCH_QUERIES = [
    "solana",
    "sol meme",
    "pump fun",   # most early memes launch here
]


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

async def fetch_new_solana_pairs() -> List[TokenPair]:
    """
    Main entry point: fetch the latest Solana pairs from multiple DexScreener
    endpoints and return a de-duplicated list of TokenPair objects.
    """
    tasks = [
        _fetch_latest_boosted(),
        _fetch_trending_solana(),
        *[_fetch_search(q) for q in _SEARCH_QUERIES],
    ]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    seen_addresses: set[str] = set()
    pairs: List[TokenPair] = []

    for result in results:
        if isinstance(result, Exception):
            log.warning("Scanner sub-task failed: %s", result)
            continue
        for p in result:
            key = p.base_token_addr or p.pair_address
            if key and key not in seen_addresses:
                seen_addresses.add(key)
                pairs.append(p)
            if len(pairs) >= MAX_PAIRS_PER_SCAN:
                break

    log.info("Scanner fetched %d unique Solana pairs", len(pairs))
    return pairs[:MAX_PAIRS_PER_SCAN]


async def fetch_pair_by_address(pair_address: str) -> Optional[TokenPair]:
    """Fetch a single pair's full data by its contract address."""
    url  = f"{_PAIRS_URL}/{pair_address}"
    data = await fetch_json(url)
    if not data:
        return None
    pairs = data.get("pairs") or []
    return _parse_pair(pairs[0]) if pairs else None


# ---------------------------------------------------------------------------
# Internal fetchers
# ---------------------------------------------------------------------------

async def _fetch_latest_boosted() -> List[TokenPair]:
    """DexScreener's boosted / promoted new pairs endpoint."""
    url  = "https://api.dexscreener.com/token-boosts/latest/v1"
    data = await fetch_json(url)
    if not data:
        return []
    token_addresses = [
        item["tokenAddress"]
        for item in (data if isinstance(data, list) else [])
        if item.get("chainId") == "solana" and item.get("tokenAddress")
    ]
    if not token_addresses:
        return []
    # Batch-resolve addresses → full pair data
    return await _fetch_pairs_for_tokens(token_addresses[:30])


async def _fetch_trending_solana() -> List[TokenPair]:
    """Fetch top-traded Solana pairs (high volume = momentum candidates)."""
    url  = f"{DEXSCREENER_BASE_URL}/pairs/solana"
    data = await fetch_json(url)
    if not data:
        return []
    raw_pairs = data.get("pairs") or []
    return [p for p in (_parse_pair(r) for r in raw_pairs) if p]


async def _fetch_search(query: str) -> List[TokenPair]:
    """Search DexScreener for a keyword and filter to Solana."""
    data = await fetch_json(_SEARCH_URL, params={"q": query})
    if not data:
        return []
    raw_pairs = data.get("pairs") or []
    return [
        p for p in (_parse_pair(r) for r in raw_pairs)
        if p and p.chain_id == "solana"
    ]


async def _fetch_pairs_for_tokens(addresses: List[str]) -> List[TokenPair]:
    """Given a list of token addresses, fetch their pair data in chunks."""
    # DexScreener allows comma-separated addresses (up to ~30)
    chunk_size = 30
    pairs: List[TokenPair] = []
    for i in range(0, len(addresses), chunk_size):
        chunk = addresses[i : i + chunk_size]
        url   = f"{_TOKEN_URL}/{','.join(chunk)}"
        data  = await fetch_json(url)
        if not data:
            continue
        for raw in data.get("pairs") or []:
            if raw.get("chainId") == "solana":
                p = _parse_pair(raw)
                if p:
                    pairs.append(p)
    return pairs


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

def _parse_pair(raw: dict) -> Optional[TokenPair]:
    """Convert a raw DexScreener pair dict into a TokenPair. Returns None on error."""
    try:
        base     = raw.get("baseToken", {})
        quote    = raw.get("quoteToken", {})
        txns     = raw.get("txns", {})
        h1_txns  = txns.get("h1", {})
        h24_txns = txns.get("h24", {})
        volume   = raw.get("volume", {})
        price_ch = raw.get("priceChange", {})
        liq      = raw.get("liquidity", {})
        info     = raw.get("info", {})

        created_at_ms = int(raw.get("pairCreatedAt", 0) or 0)
        now_ms        = int(time.time() * 1000)
        age_hours     = (now_ms - created_at_ms) / 3_600_000 if created_at_ms else 9999.0

        # DexScreener profile presence
        has_profile = bool(info.get("imageUrl") or raw.get("profile"))

        return TokenPair(
            pair_address      = raw.get("pairAddress", ""),
            base_token_addr   = base.get("address", ""),
            base_token_name   = base.get("name", "Unknown"),
            base_token_symbol = base.get("symbol", "???"),
            quote_token_addr  = quote.get("address", ""),
            dex_id            = raw.get("dexId", ""),
            chain_id          = raw.get("chainId", ""),
            price_usd         = _safe_float(raw.get("priceUsd")),
            price_change_1h   = _safe_float(price_ch.get("h1")),
            price_change_6h   = _safe_float(price_ch.get("h6")),
            price_change_24h  = _safe_float(price_ch.get("h24")),
            liquidity_usd     = _safe_float(liq.get("usd")),
            market_cap        = _safe_float(raw.get("fdv")),
            volume_24h        = _safe_float(volume.get("h24")),
            txns_1h_buys      = int(h1_txns.get("buys", 0) or 0),
            txns_1h_sells     = int(h1_txns.get("sells", 0) or 0),
            txns_24h_buys     = int(h24_txns.get("buys", 0) or 0),
            txns_24h_sells    = int(h24_txns.get("sells", 0) or 0),
            pair_created_at   = created_at_ms,
            pair_age_hours    = age_hours,
            has_profile       = has_profile,
            dex_url           = raw.get("url", f"https://dexscreener.com/solana/{raw.get('pairAddress','')}"),
        )
    except Exception as exc:
        log.debug("Failed to parse pair: %s | raw=%s", exc, str(raw)[:200])
        return None


def _safe_float(value) -> float:
    try:
        return float(value) if value is not None else 0.0
    except (ValueError, TypeError):
        return 0.0
