"""
Core data models for tokens flowing through the scanning pipeline.
Using dataclasses for speed; all fields are optional to handle partial API data.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, List
from enum import Enum


class Strategy(str, Enum):
    EARLY_MICRO_CAP  = "🧪 Early Micro-Cap"
    MID_CAP_MOMENTUM = "📈 Mid-Cap Momentum"


@dataclass
class TokenPair:
    """Raw pair data parsed from DexScreener response."""

    # Identifiers
    pair_address:      str   = ""
    base_token_addr:   str   = ""
    base_token_name:   str   = ""
    base_token_symbol: str   = ""
    quote_token_addr:  str   = ""
    dex_id:            str   = ""
    chain_id:          str   = ""

    # Pricing
    price_usd:         float = 0.0
    price_change_1h:   float = 0.0   # %
    price_change_6h:   float = 0.0   # %
    price_change_24h:  float = 0.0   # %

    # Market metrics
    liquidity_usd:     float = 0.0
    market_cap:        float = 0.0   # FDV
    volume_24h:        float = 0.0

    # Transactions
    txns_1h_buys:      int   = 0
    txns_1h_sells:     int   = 0
    txns_24h_buys:     int   = 0
    txns_24h_sells:    int   = 0

    # Metadata
    pair_created_at:   int   = 0     # unix ms
    pair_age_hours:    float = 0.0
    has_profile:       bool  = False
    dex_url:           str   = ""

    # Strategy tag (set during filtering)
    strategy:          Optional[Strategy] = None


@dataclass
class SecurityReport:
    """Result of on-chain security analysis."""

    token_address:        str   = ""
    is_mintable:          bool  = True    # True = risky
    is_lp_locked:         bool  = False
    is_honeypot:          bool  = False
    is_verified:          bool  = False
    top10_holder_pct:     float = 100.0
    owner_renounced:      bool  = False
    freeze_authority:     bool  = False   # SPL freeze = risky
    warnings:             List[str] = field(default_factory=list)
    security_score:       int   = 0       # 0–100 (higher = safer)
    raw_data:             dict  = field(default_factory=dict)


@dataclass
class ScoredToken:
    """A token that passed all filters and has a final signal score."""

    pair:             TokenPair
    security:         SecurityReport
    signal_score:     int = 0           # 0–100
    score_breakdown:  dict = field(default_factory=dict)

    # Computed alerts fields
    entry_price_usd:  float = 0.0
    tp1_usd:          float = 0.0       # +100 %
    tp2_usd:          float = 0.0       # +200 %
    tp3_usd:          float = 0.0       # +300 %
