"""
=============================================================================
 Smart Contract Security Analyser — RugCheck Only
=============================================================================
 Endpoint : GET https://api.rugcheck.xyz/v1/tokens/{address}/report

 Comportement en cas d'échec RugCheck :
   RUGCHECK_SKIP_ON_FAILURE=true  → token ignoré du filtre de sécurité
                                    (score neutre 60, aucun rejet dur)
   RUGCHECK_SKIP_ON_FAILURE=false → worst-case appliqué (rejet total)
   Par défaut : true (RugCheck est souvent rate-limité sur les free plans)

 Score de sécurité interne (0–100) :
   Départ à 100, pénalités appliquées pour chaque flag de risque RugCheck.

 Règles de rejet dur (is_safe_enough) :
   • Honeypot détecté
   • Mint authority active   (si SECURITY.reject_mint_enabled)
   • LP non verrouillée      (si SECURITY.require_lp_locked_or_burned)
   • Top-10 holders > 30 %  (configurable)
   • Contrat non vérifié     (si SECURITY.reject_unverified)
   • security_score < min_security_score
=============================================================================
"""

from __future__ import annotations

import os
from typing import Optional

from config.settings import RUGCHECK_BASE_URL, SECURITY as SEC
from utils.http_client import fetch_json
from utils.logger import get_logger
from utils.models import SecurityReport

log = get_logger(__name__)

# ---------------------------------------------------------------------------
# Comportement si RugCheck est indisponible
# ---------------------------------------------------------------------------
# true  → score neutre 60 attribué, aucun rejet dur (recommandé)
# false → worst-case appliqué, token rejeté automatiquement
SKIP_ON_RUGCHECK_FAILURE: bool = (
    os.getenv("RUGCHECK_SKIP_ON_FAILURE", "true").lower() != "false"
)

# ---------------------------------------------------------------------------
# Pénalités de score (départ à 100)
# ---------------------------------------------------------------------------
_PENALTY = {
    "is_mintable":         40,
    "is_honeypot":         50,
    "lp_not_locked":       30,
    "not_verified":        15,
    "freeze_authority":    20,
    "owner_not_renounced": 10,
    "top10_per_10pct":     20,   # par tranche de 10 % au-dessus du seuil
    "danger_warning":      15,   # par flag "danger" RugCheck
    "warn_warning":         5,   # par flag "warn" (après tolérance de 2)
}

# Mots-clés pour détecter les flags dans les libellés RugCheck
_HONEYPOT_KEYWORDS = ("honeypot", "cannot sell", "sell disabled", "transfer locked")
_MINT_KEYWORDS     = ("mint", "mint authority", "mintable")
_FREEZE_KEYWORDS   = ("freeze", "freeze authority")

# Score neutre attribué quand RugCheck est indisponible (mode SKIP)
_NEUTRAL_SCORE = 60


# ---------------------------------------------------------------------------
# Interface publique
# ---------------------------------------------------------------------------

async def analyse_token(token_address: str) -> SecurityReport:
    """
    Retourne un SecurityReport complet pour l'adresse Solana donnée.

    Si RugCheck est indisponible :
      - SKIP_ON_RUGCHECK_FAILURE=True  → rapport neutre (score=60, pas de rejet dur)
      - SKIP_ON_RUGCHECK_FAILURE=False → rapport worst-case (score=0, rejeté)
    """
    report = await _analyse_via_rugcheck(token_address)

    if report is None:
        if SKIP_ON_RUGCHECK_FAILURE:
            log.warning(
                "RugCheck indisponible pour %s — rapport neutre appliqué (score=%d)",
                token_address[:12], _NEUTRAL_SCORE,
            )
            report = _neutral_report(token_address)
        else:
            log.warning(
                "RugCheck indisponible pour %s — worst-case appliqué (token rejeté)",
                token_address[:12],
            )
            report = _worst_case_report(token_address)

    report.security_score = _calculate_score(report)

    log.debug(
        "Sécurité %s | score=%d | mint=%s | lp=%s | hp=%s | top10=%.1f%% | rugcheck_ok=%s",
        token_address[:12],
        report.security_score,
        report.is_mintable,
        report.is_lp_locked,
        report.is_honeypot,
        report.top10_holder_pct,
        not report.raw_data.get("_api_failed", False),
    )
    return report


def is_safe_enough(report: SecurityReport) -> bool:
    """
    Grille de rejet dur basée sur les flags RugCheck.
    Retourne False dès qu'un critère critique est levé.
    Si RugCheck était indisponible (mode SKIP), seul le score est vérifié.
    """
    api_failed = report.raw_data.get("_api_failed", False)

    # En mode SKIP, on ne peut pas vérifier les flags individuels →
    # on se fie uniquement au score neutre (60 > min_security_score=55 → passe)
    if not api_failed:
        if report.is_honeypot:
            log.debug("Rejeté — honeypot: %s", report.token_address[:12])
            return False

        if report.is_mintable and SEC.reject_mint_enabled:
            log.debug("Rejeté — mint active: %s", report.token_address[:12])
            return False

        if not report.is_lp_locked and SEC.require_lp_locked_or_burned:
            log.debug("Rejeté — LP non verrouillée: %s", report.token_address[:12])
            return False

        if report.top10_holder_pct > SEC.max_top10_holder_pct:
            log.debug(
                "Rejeté — top10=%.1f%% > %.1f%%: %s",
                report.top10_holder_pct, SEC.max_top10_holder_pct,
                report.token_address[:12],
            )
            return False

        if not report.is_verified and SEC.reject_unverified:
            log.debug("Rejeté — non vérifié: %s", report.token_address[:12])
            return False

    # Vérification du score (s'applique toujours)
    if report.security_score < SEC.min_security_score:
        log.debug(
            "Rejeté — score %d < %d: %s",
            report.security_score, SEC.min_security_score,
            report.token_address[:12],
        )
        return False

    return True


# ---------------------------------------------------------------------------
# Analyse RugCheck
# ---------------------------------------------------------------------------

async def _analyse_via_rugcheck(token_address: str) -> Optional[SecurityReport]:
    """
    Appel à l'API RugCheck.
    Retourne None si la réponse est invalide, absente, ou en erreur.
    """
    url  = f"{RUGCHECK_BASE_URL}/tokens/{token_address}/report"
    data = await fetch_json(url)

    if not data:
        log.warning("RugCheck : réponse vide pour %s", token_address[:12])
        return None

    # RugCheck retourne parfois {"message": "Token not found"} ou {"error": "..."}
    if "risks" not in data and "tokenMeta" not in data:
        log.warning(
            "RugCheck : données insuffisantes pour %s — réponse: %s",
            token_address[:12], str(data)[:150],
        )
        return None

    try:
        return _parse_rugcheck_response(token_address, data)
    except Exception as exc:
        log.warning(
            "RugCheck : erreur de parsing pour %s — %s", token_address[:12], exc
        )
        return None


def _parse_rugcheck_response(token_address: str, data: dict) -> SecurityReport:
    """
    Convertit la réponse brute RugCheck en SecurityReport.
    """
    risks: list[dict] = data.get("risks") or []

    # Textes de risque normalisés pour keyword matching
    risk_names_lower = [r.get("name", "").lower() for r in risks]
    risk_descs_lower = [r.get("description", "").lower() for r in risks]
    all_risk_texts   = risk_names_lower + risk_descs_lower

    # ── Flags critiques ──────────────────────────────────────────────────
    is_honeypot = _any_keyword_match(all_risk_texts, _HONEYPOT_KEYWORDS)
    is_mintable = (
        data.get("mintAuthority") is not None
        or _any_keyword_match(risk_names_lower, _MINT_KEYWORDS)
    )
    freeze_auth = (
        data.get("freezeAuthority") is not None
        or _any_keyword_match(risk_names_lower, _FREEZE_KEYWORDS)
    )

    # ── Liquidité verrouillée / brûlée ───────────────────────────────────
    markets: list[dict] = data.get("markets") or []
    lp_locked = any(
        bool(m.get("liquidityLocked")) or bool(m.get("lpBurned"))
        for m in markets
    )

    # ── Concentration des top holders ────────────────────────────────────
    top_holders: list[dict] = data.get("topHolders") or []
    top10_pct = sum(
        float(h.get("pct", 0) or 0)
        for h in top_holders[:10]
    )

    # ── Statut de vérification ───────────────────────────────────────────
    is_verified     = (data.get("mintAuthority") is None and data.get("freezeAuthority") is None)
    owner_renounced = data.get("mintAuthority") is None

    # ── Avertissements classés par niveau ────────────────────────────────
    danger_warnings = [
        f"[DANGER] {r.get('name', '')}: {r.get('description', '')}"
        for r in risks
        if r.get("level") in ("danger", "critical")
    ]
    warn_warnings = [
        f"[WARN] {r.get('name', '')}: {r.get('description', '')}"
        for r in risks
        if r.get("level") == "warn"
    ]

    return SecurityReport(
        token_address    = token_address,
        is_mintable      = is_mintable,
        is_lp_locked     = lp_locked,
        is_honeypot      = is_honeypot,
        is_verified      = is_verified,
        top10_holder_pct = top10_pct,
        owner_renounced  = owner_renounced,
        freeze_authority = freeze_auth,
        warnings         = (danger_warnings + warn_warnings)[:10],
        raw_data         = data,   # _api_failed absent → API a répondu
    )


# ---------------------------------------------------------------------------
# Calcul du score de sécurité (0–100)
# ---------------------------------------------------------------------------

def _calculate_score(report: SecurityReport) -> int:
    # Si le rapport est neutre (API indisponible + mode SKIP), retourner le score neutre
    if report.raw_data.get("_api_failed") and report.raw_data.get("_neutral"):
        return _NEUTRAL_SCORE

    score = 100

    if report.is_mintable:       score -= _PENALTY["is_mintable"]
    if report.is_honeypot:       score -= _PENALTY["is_honeypot"]
    if not report.is_lp_locked:  score -= _PENALTY["lp_not_locked"]
    if not report.is_verified:   score -= _PENALTY["not_verified"]
    if report.freeze_authority:  score -= _PENALTY["freeze_authority"]
    if not report.owner_renounced: score -= _PENALTY["owner_not_renounced"]

    excess = max(0.0, report.top10_holder_pct - SEC.max_top10_holder_pct)
    score -= int(excess / 10) * _PENALTY["top10_per_10pct"]

    danger_count = sum(1 for w in report.warnings if w.startswith("[DANGER]"))
    warn_count   = sum(1 for w in report.warnings if w.startswith("[WARN]"))
    extra_warns  = max(0, warn_count - 2)

    score -= danger_count * _PENALTY["danger_warning"]
    score -= extra_warns  * _PENALTY["warn_warning"]

    return max(0, min(100, score))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _any_keyword_match(texts: list[str], keywords: tuple[str, ...]) -> bool:
    return any(kw in text for text in texts for kw in keywords)


def _neutral_report(token_address: str) -> SecurityReport:
    """
    Rapport neutre utilisé quand RugCheck est indisponible et SKIP=true.
    Le token n'est PAS rejeté — il continue dans le pipeline avec score=60.
    L'alerte Telegram indiquera que RugCheck était indisponible.
    """
    return SecurityReport(
        token_address    = token_address,
        is_mintable      = False,   # on ne sait pas → hypothèse neutre
        is_lp_locked     = True,    # hypothèse neutre
        is_honeypot      = False,
        is_verified      = True,    # hypothèse neutre
        top10_holder_pct = 25.0,    # hypothèse neutre (sous le seuil de 30%)
        owner_renounced  = True,
        freeze_authority = False,
        warnings         = ["⚠️ RugCheck indisponible — données de sécurité non vérifiées"],
        raw_data         = {"_api_failed": True, "_neutral": True},
    )


def _worst_case_report(token_address: str) -> SecurityReport:
    """
    Rapport conservateur — token rejeté automatiquement.
    Utilisé uniquement si RUGCHECK_SKIP_ON_FAILURE=false.
    """
    return SecurityReport(
        token_address    = token_address,
        is_mintable      = True,
        is_lp_locked     = False,
        is_honeypot      = True,
        is_verified      = False,
        top10_holder_pct = 100.0,
        owner_renounced  = False,
        freeze_authority = True,
        warnings         = ["[DANGER] API RugCheck inaccessible — worst-case appliqué"],
        raw_data         = {"_api_failed": True, "_neutral": False},
    )
