# 🚀 Solana Memecoin Alpha Bot

A **production-ready async Telegram bot** that detects high-potential early memecoins on Solana using DexScreener data and smart contract security analysis. Designed for precision — only signals with score ≥ 80/100 are sent.

---

## 📁 Project Architecture

```
solana_memecoin_bot/
│
├── main.py                  # Entry point — async scheduler loop
├── pipeline.py              # Core orchestrator tying all modules together
│
├── config/
│   ├── __init__.py
│   └── settings.py          # All thresholds, API URLs, env-driven config
│
├── scanner/
│   ├── __init__.py
│   └── dexscreener.py       # DexScreener API fetcher + parser
│
├── filters/
│   ├── __init__.py
│   └── strategies.py        # EMC & MCM strategy filter pipelines
│
├── security/
│   ├── __init__.py
│   └── analyser.py          # RugCheck + GoPlus security analysis + scoring
│
├── scoring/
│   ├── __init__.py
│   └── engine.py            # 6-dimension signal scoring engine (0–100)
│
├── telegram/
│   ├── __init__.py
│   └── alerts.py            # HTML alert formatter + Telegram Bot API sender
│
├── data/
│   ├── __init__.py
│   └── store.py             # Token deduplication (memory or Redis)
│
├── utils/
│   ├── __init__.py
│   ├── models.py            # TokenPair, SecurityReport, ScoredToken dataclasses
│   ├── logger.py            # Rotating file + console logger
│   └── http_client.py       # Shared aiohttp session, retry, rate-limit handling
│
├── tests/
│   ├── __init__.py
│   └── test_filters_scoring.py   # 22 unit tests — all pass
│
├── requirements.txt
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── render.yaml              # Render.com deployment config
└── solana-alpha-bot.service # Systemd unit for VPS
```

---

## ⚙️ How It Works — Full Pipeline

```
Every 90 seconds:

DexScreener API
    │
    ▼  (fetch_new_solana_pairs)
[~200 raw Solana pairs]
    │
    ▼  (classify_pair — EMC or MCM filter)
[Pairs matching a strategy]
    │
    ▼  (deduplication check — memory/Redis)
[Only NEW, unseen tokens]
    │
    ▼  (analyse_token — RugCheck → GoPlus fallback, concurrent)
[SecurityReport per token]
    │
    ▼  (is_safe_enough — hard security gates)
[Tokens passing all security checks]
    │
    ▼  (score_token — 6-dimension scoring)
[ScoredToken with signal_score 0–100]
    │
    ▼  (passes_signal_threshold — score ≥ 80)
[ALERT-WORTHY tokens]
    │
    ▼  (send_alert — Telegram Bot API)
📲 Rich HTML message sent to channel
```

---

## 🎯 Signal Scoring System (0–100)

| Dimension           | Max Pts | Logic |
|---------------------|---------|-------|
| Liquidity strength  | 15      | Log curve, sweet-spot $5k–$50k (EMC) |
| Volume / Liq ratio  | 20      | Vol÷Liq ratio; >5x = maximum score |
| Transaction activity| 15      | Log of 24h txns + buy/sell sentiment |
| Wallet distribution | 15      | Top-10 concentration penalty tiers |
| Price momentum      | 20      | Weighted 1h (8), 6h (7), 24h (5) |
| Age premium         | 15      | 0–6h=15pts, 6–12h=12, 12–24h=8, etc. |
| Security bonus      | 10      | sec_score ÷ 10 |
| **Total**           | **110** → clamped to **100** |

**Minimum to alert: 80/100**

---

## 🛡️ Security Score (0–100)

Starts at 100, penalties applied:

| Risk Flag              | Penalty |
|------------------------|---------|
| Mint authority active  | −40     |
| Honeypot detected      | −50     |
| LP not locked/burned   | −30     |
| Contract not verified  | −15     |
| Freeze authority        | −20     |
| Owner not renounced    | −10     |
| Top-10 hold > 30%      | −20 per 10% over |
| Critical warnings       | −15 each (after 2nd) |

**Hard reject if:** honeypot=true, mint active, LP unlocked, top10>30%, score<60.

---

## 🔧 Local Setup

### Prerequisites
- Python 3.11+
- A Telegram bot token from [@BotFather](https://t.me/BotFather)
- Your Telegram channel/group ID

### Step 1 — Clone and install

```bash
git clone https://github.com/yourname/solana_memecoin_bot.git
cd solana_memecoin_bot

python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

pip install -r requirements.txt
```

### Step 2 — Configure environment

```bash
cp .env.example .env
nano .env   # fill in TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID
```

**.env minimum required:**
```env
TELEGRAM_BOT_TOKEN=7123456789:ABCdef...
TELEGRAM_CHAT_ID=-1001234567890
```

### Step 3 — Run tests

```bash
PYTHONPATH=. python -m pytest tests/ -v
```

All 22 tests should pass.

### Step 4 — Start the bot

```bash
PYTHONPATH=. python main.py
```

You'll see a startup message in your Telegram channel and logs in `bot.log`.

---

## 📲 Telegram Bot Setup (Step by Step)

1. **Create the bot:**
   - Open Telegram → search `@BotFather`
   - Send `/newbot` → choose a name → copy the **token**

2. **Create a channel or group:**
   - Create a private Telegram channel (e.g., "Solana Alpha Signals")
   - Add your bot as an **administrator** with "Post Messages" permission

3. **Get the chat ID:**
   - For a channel: `@yourchannelusername` (or use the numeric ID)
   - For a group: add `@userinfobot` to the group → it will show the group ID
   - Or visit: `https://api.telegram.org/bot<TOKEN>/getUpdates` after sending a message

4. **Paste into `.env`:**
   ```env
   TELEGRAM_BOT_TOKEN=your_token
   TELEGRAM_CHAT_ID=-1001234567890   # channels are negative IDs
   ```

---

## ☁️ Deployment

### Option A — Render.com (Easiest, ~$7/mo)

1. Push code to GitHub
2. Go to [render.com](https://render.com) → New → **Background Worker**
3. Connect your GitHub repo
4. Set environment variables in Render dashboard (use the secret fields):
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
5. Render auto-detects `render.yaml` and deploys on every push

### Option B — Docker (Local or any VPS)

```bash
# Build and run with compose (includes Redis)
docker compose up -d

# View logs
docker compose logs -f bot

# Stop
docker compose down
```

### Option C — VPS with systemd (Ubuntu/Debian)

```bash
# On your VPS:
git clone https://github.com/yourname/solana_memecoin_bot /home/ubuntu/solana_memecoin_bot
cd /home/ubuntu/solana_memecoin_bot

python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
nano .env   # fill in secrets

# Install as a system service
sudo cp solana-alpha-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable solana-alpha-bot
sudo systemctl start  solana-alpha-bot

# Check status
sudo systemctl status solana-alpha-bot
sudo journalctl -u solana-alpha-bot -f
```

**Recommended VPS:** DigitalOcean $6/mo droplet (1GB RAM) or Hetzner CX11.

---

## 🔧 Configuration Tuning

Edit `config/settings.py` to adjust thresholds. Key parameters:

| Parameter | Default | Effect |
|-----------|---------|--------|
| `SCAN_INTERVAL` | 90s | Lower = faster detection, higher API usage |
| `EARLY_MICRO_CAP.max_pair_age_hours` | 48h | Widen to catch slightly older gems |
| `EARLY_MICRO_CAP.min_volume_24h_usd` | $30k | Lower = more signals, lower quality |
| `SECURITY.max_top10_holder_pct` | 30% | Raise to allow more concentrated tokens |
| `MIN_SIGNAL_SCORE` | 80 | Lower = more alerts, raise = only best |
| `MAX_CONCURRENT_REQUESTS` | 10 | Limit if hitting API rate limits |

---

## 📊 Sample Alert

```
🧪 Early Micro-Cap

💎 PepeSolana  $PEPES

📋 Contract:
Eg8A3kWM9...Xj2k

━━━━━━━ 📊 MARKET DATA ━━━━━━━
💰 Price:      $0.000025
📦 Market Cap: $62.5K
💧 Liquidity:  $22.0K
📈 Vol (24h):  $84.0K  (Vol/Liq: 3.8x)
⏱ Age:        6.2h

━━━━━━━ 🕹 PRICE ACTION ━━━━━━
1h:  🟢 +15.4%
6h:  🟢 +42.1%
24h: 🟢 +81.0%

━━━━━━━ 🔁 TRANSACTIONS ━━━━━━
Last 1h:  97 (82🟢 / 15🔴)  Buy: 84%
Last 24h: 310 (260🟢 / 50🔴)

━━━━━━━ 🛡 SECURITY ━━━━━━━━━
Score:       🟢  90/100
Mint:        ✅ Disabled
LP:          ✅ Locked/Burned
Honeypot:    ✅ No
Verified:    ✅ Yes
Top 10 Hold: 18.0%  ✅ Normal
Owner:       ✅ Renounced

━━━━━━━ 🎯 SIGNAL SCORE ━━━━━
████████░░  83/100

━━━━━━━ 💸 TARGETS ━━━━━━━━━━
🔵 Entry:     $0.000025
🟡 TP1 +100%: $0.000050
🟠 TP2 +200%: $0.000075
🔴 TP3 +300%: $0.000100

🔗 DexScreener Chart
🔗 Solscan  🔗 RugCheck

⚡ DYOR. Not financial advice. High-risk asset.
```

---

## ⚠️ Disclaimers

- **This bot does NOT execute trades.** It is a signal/alert tool only.
- Memecoins are extremely high-risk. Most go to zero.
- Security checks reduce but do NOT eliminate rug-pull risk.
- Always do your own research before trading.
- Past signal performance does not guarantee future results.

---

## 📄 License

MIT — use freely, deploy responsibly.
