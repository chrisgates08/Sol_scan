import httpx
from config import GOPLUS_API_KEY

GOPLUS_BASE = "https://api.gopluslabs.io"

async def check_token_security(token_address: str) -> dict:
    """
    Endpoint officiel GoPlus Solana :
    GET /api/v1/solana/token_security?contract_addresses={address}
    Analyse de sécurité complète d'un token SPL Solana.
    """
    url     = f"{GOPLUS_BASE}/api/v1/solana/token_security"
    headers = {}
    if GOPLUS_API_KEY:
        headers["Authorization"] = GOPLUS_API_KEY

    params = {"contract_addresses": token_address}

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(url, params=params, headers=headers)
            resp.raise_for_status()
            data = resp.json()

            if data.get("code") != 1:
                return {"error": f"GoPlus code: {data.get('message', 'unknown')}"}

            result     = data.get("result", {})
            token_data = result.get(token_address.lower(),
                         result.get(token_address, {}))

            if not token_data:
                return {"error": "Token non trouvé dans GoPlus"}

            return parse_goplus_result(token_data)

    except Exception as e:
        print(f"[GoPlus] Erreur check_token_security: {e}")
        return {"error": str(e)}


def parse_goplus_result(data: dict) -> dict:
    """Parse les champs de sécurité retournés par GoPlus pour Solana."""

    def to_float(val, default=0.0):
        try: return float(val)
        except: return default

    def to_int(val, default=0):
        try: return int(val)
        except: return default

    # Top 10 holders (plusieurs noms de champ possibles selon la version)
    top10 = data.get("top10_holders_ratio") or data.get("top_10_holders_rate")

    # Creator / deployer percent
    creator_pct = to_float(data.get("creator_percent", 0))
    if creator_pct == 0:
        creator_pct = to_float(data.get("deployer_percent", 0))

    # LP Lock
    lp_locked      = data.get("lp_locked", "0")
    is_lp_locked   = str(lp_locked) in ("1", "true", "True")
    lock_days      = 0
    lp_lock_detail = data.get("lp_lock_detail", [])
    if isinstance(lp_lock_detail, list) and lp_lock_detail:
        import time
        now = time.time()
        for lock in lp_lock_detail:
            end_time = to_float(lock.get("end_time", 0))
            if end_time > now:
                lock_days = max(lock_days, int((end_time - now) / 86400))

    return {
        "is_honeypot":         data.get("honeypot", "0") == "1",
        "is_mintable":         data.get("mintable", "0") == "1",
        "is_freezable":        data.get("freezable", "0") == "1",
        "top10_holders_ratio": to_float(top10) if top10 is not None else None,
        "creator_percent":     creator_pct,
        "is_lp_locked":        is_lp_locked,
        "lp_lock_days":        lock_days,
        "holder_count":        to_int(data.get("holder_count", 0)),
        "total_supply":        data.get("total_supply", "0"),
        "buy_tax":             to_float(data.get("buy_tax", 0)),
        "sell_tax":            to_float(data.get("sell_tax", 0)),
        "cannot_sell_all":     data.get("cannot_sell_all", "0") == "1",
        "error":               None,
    }
