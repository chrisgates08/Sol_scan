"""
=============================================================================
 Deduplication Store
=============================================================================
 Tracks which tokens have already been alerted to avoid repeat signals.
 Two backends:
   • MemoryStore  — default; process-local dict with TTL sweep
   • RedisStore   — optional; for multi-process / persistent memory
=============================================================================
"""

from __future__ import annotations

import asyncio
import time
from abc import ABC, abstractmethod
from typing import Set

from config.settings import SEEN_TOKENS_TTL_HOURS, USE_REDIS, REDIS_URL
from utils.logger import get_logger

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------

class BaseStore(ABC):
    @abstractmethod
    async def is_seen(self, token_address: str) -> bool: ...

    @abstractmethod
    async def mark_seen(self, token_address: str) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...


# ---------------------------------------------------------------------------
# In-memory store (default)
# ---------------------------------------------------------------------------

class MemoryStore(BaseStore):
    """Thread-safe in-memory TTL store using a plain dict."""

    def __init__(self, ttl_hours: float = SEEN_TOKENS_TTL_HOURS):
        self._ttl_seconds = ttl_hours * 3600
        self._store: dict[str, float] = {}   # address → expiry_timestamp
        self._lock = asyncio.Lock()

    async def is_seen(self, token_address: str) -> bool:
        async with self._lock:
            self._sweep()
            return token_address in self._store

    async def mark_seen(self, token_address: str) -> None:
        async with self._lock:
            self._store[token_address] = time.time() + self._ttl_seconds
            log.debug("Marked as seen: %s", token_address[:12])

    async def close(self) -> None:
        self._store.clear()

    def _sweep(self) -> None:
        """Remove expired entries (called inline to keep memory bounded)."""
        now = time.time()
        expired = [k for k, v in self._store.items() if v < now]
        for k in expired:
            del self._store[k]
        if expired:
            log.debug("Swept %d expired tokens from memory store", len(expired))

    @property
    def size(self) -> int:
        return len(self._store)


# ---------------------------------------------------------------------------
# Redis store (optional)
# ---------------------------------------------------------------------------

class RedisStore(BaseStore):
    """Redis-backed store with native TTL expiry."""

    def __init__(self, redis_url: str = REDIS_URL, ttl_hours: float = SEEN_TOKENS_TTL_HOURS):
        self._redis_url  = redis_url
        self._ttl        = int(ttl_hours * 3600)
        self._prefix     = "sol_alpha_bot:seen:"
        self._client     = None

    async def _get_client(self):
        if self._client is None:
            try:
                import aioredis  # type: ignore
                self._client = await aioredis.from_url(
                    self._redis_url, encoding="utf-8", decode_responses=True
                )
                log.info("Connected to Redis at %s", self._redis_url)
            except Exception as exc:
                log.error("Redis connection failed: %s — falling back to memory", exc)
                raise
        return self._client

    async def is_seen(self, token_address: str) -> bool:
        try:
            client = await self._get_client()
            return bool(await client.exists(self._prefix + token_address))
        except Exception:
            return False

    async def mark_seen(self, token_address: str) -> None:
        try:
            client = await self._get_client()
            await client.setex(self._prefix + token_address, self._ttl, "1")
        except Exception as exc:
            log.warning("Redis mark_seen failed: %s", exc)

    async def close(self) -> None:
        if self._client:
            await self._client.close()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

_store_instance: BaseStore | None = None


async def get_store() -> BaseStore:
    global _store_instance
    if _store_instance is None:
        if USE_REDIS:
            try:
                s = RedisStore()
                await s._get_client()   # test connection
                _store_instance = s
                log.info("Using Redis deduplication store")
            except Exception:
                log.warning("Falling back to in-memory store")
                _store_instance = MemoryStore()
        else:
            _store_instance = MemoryStore()
            log.info("Using in-memory deduplication store")
    return _store_instance


async def close_store() -> None:
    global _store_instance
    if _store_instance:
        await _store_instance.close()
        _store_instance = None
