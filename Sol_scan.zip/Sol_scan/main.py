"""
=============================================================================
 Solana Memecoin Alpha Bot — Main Entry Point
=============================================================================
 Async scheduler that runs the scan pipeline every SCAN_INTERVAL_SECONDS.
 Handles graceful shutdown (SIGINT / SIGTERM), startup notifications,
 and top-level error recovery so the bot never silently dies.

 Usage:
   python main.py
=============================================================================
"""

from __future__ import annotations

import asyncio
import signal
import sys
import traceback
from datetime import datetime, timezone

from config          import validate_env, SCAN_INTERVAL_SECONDS
from pipeline        import run_scan_cycle
from telegram        import send_startup_message, send_error_notification
from data            import close_store
from utils.http_client import close_session
from utils.logger    import setup_logging, get_logger

setup_logging()
log = get_logger("main")

# Global flag for graceful shutdown
_shutdown = asyncio.Event()


# ---------------------------------------------------------------------------
# Signal handling
# ---------------------------------------------------------------------------

def _handle_signal(sig, frame):
    log.info("Received signal %s — initiating graceful shutdown…", sig)
    _shutdown.set()


# ---------------------------------------------------------------------------
# Stats tracker
# ---------------------------------------------------------------------------

class Stats:
    def __init__(self):
        self.cycles      = 0
        self.total_fetch = 0
        self.total_alert = 0
        self.errors      = 0
        self.started_at  = datetime.now(tz=timezone.utc)

    def record(self, fetched: int, _filtered: int, _secure: int, alerted: int):
        self.cycles      += 1
        self.total_fetch += fetched
        self.total_alert += alerted

    def summary(self) -> str:
        uptime = datetime.now(tz=timezone.utc) - self.started_at
        h, rem = divmod(int(uptime.total_seconds()), 3600)
        m, s   = divmod(rem, 60)
        return (
            f"Uptime {h}h{m}m{s}s | "
            f"Cycles: {self.cycles} | "
            f"Fetched: {self.total_fetch} | "
            f"Alerted: {self.total_alert} | "
            f"Errors: {self.errors}"
        )


# ---------------------------------------------------------------------------
# Main scheduler loop
# ---------------------------------------------------------------------------

async def scheduler(stats: Stats) -> None:
    """Run scan cycles on a fixed interval until shutdown is requested."""
    log.info("Scheduler started — interval: %ds", SCAN_INTERVAL_SECONDS)

    while not _shutdown.is_set():
        cycle_num = stats.cycles + 1
        log.info("═══════════ CYCLE #%d ═══════════", cycle_num)

        try:
            result = await run_scan_cycle()
            stats.record(*result)
        except asyncio.CancelledError:
            log.info("Scheduler cancelled — exiting loop")
            break
        except Exception as exc:
            stats.errors += 1
            tb = traceback.format_exc()
            log.error("Unhandled error in scan cycle #%d:\n%s", cycle_num, tb)
            try:
                await send_error_notification(f"Cycle #{cycle_num} error: {exc}")
            except Exception:
                pass   # don't let alert errors crash the loop

        # Log periodic stats every 10 cycles
        if stats.cycles % 10 == 0:
            log.info("📊 Stats — %s", stats.summary())

        # Wait for next cycle or shutdown signal
        try:
            await asyncio.wait_for(
                asyncio.shield(_shutdown.wait()),
                timeout=SCAN_INTERVAL_SECONDS,
            )
        except asyncio.TimeoutError:
            pass   # normal — interval elapsed, run next cycle


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def main() -> None:
    # ── Validate env ──────────────────────────────────────────────────────
    try:
        validate_env()
    except EnvironmentError as exc:
        print(f"[FATAL] {exc}", file=sys.stderr)
        sys.exit(1)

    log.info("🚀 Solana Alpha Bot starting up…")
    log.info("   Scan interval : %ds", SCAN_INTERVAL_SECONDS)

    # ── Register OS signals ───────────────────────────────────────────────
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, _handle_signal)

    stats = Stats()

    # ── Startup notification ──────────────────────────────────────────────
    try:
        await send_startup_message()
    except Exception as exc:
        log.warning("Could not send startup message: %s", exc)

    # ── Run scheduler ─────────────────────────────────────────────────────
    try:
        await scheduler(stats)
    finally:
        log.info("🛑 Shutting down — final stats: %s", stats.summary())
        await close_store()
        await close_session()
        log.info("✅ Clean shutdown complete.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
