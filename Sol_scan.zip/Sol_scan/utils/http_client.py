"""
Async HTTP client wrapper.
- Connection pooling via a single aiohttp.ClientSession
- Exponential back-off on 429 / 5xx
- Structured error logging
"""

from __future__ import annotations

import asyncio
import aiohttp
from typing import Optional, Any

from config.settings import REQUEST_TIMEOUT_SECONDS, USER_AGENT
from utils.logger import get_logger

log = get_logger(__name__)

_session: Optional[aiohttp.ClientSession] = None


async def get_session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        connector = aiohttp.TCPConnector(
            limit=50,
            ttl_dns_cache=300,
            ssl=False,  # set True in production with proper certs
        )
        timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT_SECONDS)
        _session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={"User-Agent": USER_AGENT},
        )
    return _session


async def close_session() -> None:
    global _session
    if _session and not _session.closed:
        await _session.close()
        _session = None


async def fetch_json(
    url: str,
    params: Optional[dict] = None,
    headers: Optional[dict] = None,
    retries: int = 3,
    backoff_base: float = 1.5,
) -> Optional[Any]:
    """
    GET a URL and return parsed JSON.
    Returns None on permanent failure (logged).
    """
    session = await get_session()
    for attempt in range(1, retries + 1):
        try:
            async with session.get(url, params=params, headers=headers) as resp:
                if resp.status == 200:
                    return await resp.json(content_type=None)
                if resp.status == 429:
                    wait = backoff_base ** attempt
                    log.warning("Rate limited by %s — sleeping %.1fs", url, wait)
                    await asyncio.sleep(wait)
                    continue
                if resp.status >= 500:
                    wait = backoff_base ** attempt
                    log.warning("Server error %d from %s — retry %d", resp.status, url, attempt)
                    await asyncio.sleep(wait)
                    continue
                log.debug("Non-200 response %d from %s", resp.status, url)
                return None
        except asyncio.TimeoutError:
            log.warning("Timeout on %s (attempt %d/%d)", url, attempt, retries)
        except aiohttp.ClientError as exc:
            log.warning("Client error on %s: %s (attempt %d/%d)", url, exc, attempt, retries)
        await asyncio.sleep(backoff_base ** attempt)
    log.error("All %d attempts failed for %s", retries, url)
    return None


async def fetch_post_json(
    url: str,
    payload: dict,
    headers: Optional[dict] = None,
    retries: int = 3,
    backoff_base: float = 1.5,
) -> Optional[Any]:
    """POST with JSON body, return parsed JSON."""
    session = await get_session()
    for attempt in range(1, retries + 1):
        try:
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status == 200:
                    return await resp.json(content_type=None)
                if resp.status in (429, 503):
                    wait = backoff_base ** attempt
                    await asyncio.sleep(wait)
                    continue
                return None
        except (asyncio.TimeoutError, aiohttp.ClientError) as exc:
            log.warning("POST %s error: %s (attempt %d)", url, exc, attempt)
            await asyncio.sleep(backoff_base ** attempt)
    return None
