"""
=============================================================================
 Smart Contract Security Analyser — RugCheck Only
=============================================================================
 Utilise exclusivement l'API RugCheck pour analyser les contrats Solana.

 Endpoint:  GET https://api.rugcheck.xyz/v1/tokens/{address}/report

 Score de sécurité interne (0–100) :
   Départ à 100, pénalités appliquées pour chaque flag de risque.

 Règles de rejet dur (is_safe_enough) :
   • Honeypot détecté
   • Mint authority active   (si SECURITY.reject_mint_enabled)
   • LP non verrouillée      (si SECURITY.require_lp_locked_or_burned)
   • Top-10 holders > 30 %  (configurable)
   • Contrat non vérifié     (si SECURITY.reject_unverified)
   • security_score < min_security_score
=============================================================================
"""

from __future__ import annotations

from typing import Optional

from config.settings import RUGCHECK_BASE_URL, SECURITY as SEC
from utils.http_client import fetch_json
from utils.logger import get_logger
from utils.models import SecurityReport

log = get_logger(__name__)

# ---------------------------------------------------------------------------
# Pénalités de score (départ à 100)
# ---------------------------------------------------------------------------
_PENALTY = {
    "is_mintable":         40,
    "is_honeypot":         50,
    "lp_not_locked":       30,
    "not_verified":        15,
    "freeze_authority":    20,
    "owner_not_renounced": 10,
    "top10_per_10pct":     20,   # par tranche de 10 % au-dessus du seuil
    "danger_warning":      15,   # par avertissement "danger"
    "warn_warning":         5,   # par avertissement "warn" (après tolérance de 2)
}

# Mots-clés pour détecter les flags dans les libellés RugCheck
_HONEYPOT_KEYWORDS = ("honeypot", "cannot sell", "sell disabled", "transfer locked")
_MINT_KEYWORDS     = ("mint", "mint authority", "mintable")
_FREEZE_KEYWORDS   = ("freeze", "freeze authority")


# ---------------------------------------------------------------------------
# Interface publique
# ---------------------------------------------------------------------------

async def analyse_token(token_address: str) -> SecurityReport:
    """
    Retourne un SecurityReport complet pour l'adresse Solana donnée.
    En cas d'échec de RugCheck, retourne un rapport worst-case
    (le token sera rejeté par is_safe_enough).
    """
    report = await _analyse_via_rugcheck(token_address)

    if report is None:
        log.warning(
            "RugCheck indisponible pour %s — worst-case appliqué", token_address[:12]
        )
        report = _worst_case_report(token_address)

    report.security_score = _calculate_score(report)

    log.debug(
        "Sécurité %s | score=%d | mint=%s | lp=%s | hp=%s | top10=%.1f%%",
        token_address[:12],
        report.security_score,
        report.is_mintable,
        report.is_lp_locked,
        report.is_honeypot,
        report.top10_holder_pct,
    )
    return report


def is_safe_enough(report: SecurityReport) -> bool:
    """
    Grille de rejet dur basée sur les flags RugCheck.
    Retourne False dès qu'un critère critique est levé.
    """
    if report.is_honeypot:
        log.debug("Rejeté — honeypot: %s", report.token_address[:12])
        return False

    if report.is_mintable and SEC.reject_mint_enabled:
        log.debug("Rejeté — mint active: %s", report.token_address[:12])
        return False

    if not report.is_lp_locked and SEC.require_lp_locked_or_burned:
        log.debug("Rejeté — LP non verrouillée: %s", report.token_address[:12])
        return False

    if report.top10_holder_pct > SEC.max_top10_holder_pct:
        log.debug(
            "Rejeté — top10=%.1f%% > %.1f%%: %s",
            report.top10_holder_pct, SEC.max_top10_holder_pct,
            report.token_address[:12],
        )
        return False

    if not report.is_verified and SEC.reject_unverified:
        log.debug("Rejeté — non vérifié: %s", report.token_address[:12])
        return False

    if report.security_score < SEC.min_security_score:
        log.debug(
            "Rejeté — score %d < %d: %s",
            report.security_score, SEC.min_security_score,
            report.token_address[:12],
        )
        return False

    return True


# ---------------------------------------------------------------------------
# Analyse RugCheck
# ---------------------------------------------------------------------------

async def _analyse_via_rugcheck(token_address: str) -> Optional[SecurityReport]:
    """
    Appel à l'API RugCheck.
    Retourne None si la réponse est invalide ou absente.
    """
    url  = f"{RUGCHECK_BASE_URL}/tokens/{token_address}/report"
    data = await fetch_json(url)

    if not data:
        log.warning("RugCheck : réponse vide pour %s", token_address[:12])
        return None

    # RugCheck renvoie parfois {"message": "Token not found"} sans les clés attendues
    if "risks" not in data and "tokenMeta" not in data:
        log.warning(
            "RugCheck : données insuffisantes pour %s — réponse: %s",
            token_address[:12], str(data)[:120],
        )
        return None

    try:
        return _parse_rugcheck_response(token_address, data)
    except Exception as exc:
        log.warning(
            "RugCheck : erreur de parsing pour %s — %s", token_address[:12], exc
        )
        return None


def _parse_rugcheck_response(token_address: str, data: dict) -> SecurityReport:
    """
    Convertit la réponse brute RugCheck en SecurityReport.
    """
    risks: list[dict] = data.get("risks") or []

    # Textes de risque normalisés pour matching
    risk_names_lower = [r.get("name", "").lower() for r in risks]
    risk_descs_lower = [r.get("description", "").lower() for r in risks]
    all_risk_texts   = risk_names_lower + risk_descs_lower

    # ── Flags critiques ──────────────────────────────────────────────────
    is_honeypot = _any_keyword_match(all_risk_texts, _HONEYPOT_KEYWORDS)

    is_mintable = (
        data.get("mintAuthority") is not None
        or _any_keyword_match(risk_names_lower, _MINT_KEYWORDS)
    )

    freeze_auth = (
        data.get("freezeAuthority") is not None
        or _any_keyword_match(risk_names_lower, _FREEZE_KEYWORDS)
    )

    # ── Liquidité verrouillée ────────────────────────────────────────────
    markets: list[dict] = data.get("markets") or []
    lp_locked = any(
        bool(m.get("liquidityLocked")) or bool(m.get("lpBurned"))
        for m in markets
    )

    # ── Concentration des top holders ────────────────────────────────────
    top_holders: list[dict] = data.get("topHolders") or []
    top10_pct = sum(
        float(h.get("pct", 0) or 0)
        for h in top_holders[:10]
    )

    # ── Statut de vérification ───────────────────────────────────────────
    # RugCheck considère un token "propre" si mint ET freeze authorities sont nulles
    is_verified     = (data.get("mintAuthority") is None and data.get("freezeAuthority") is None)
    owner_renounced = data.get("mintAuthority") is None

    # ── Avertissements classés par niveau ────────────────────────────────
    danger_warnings = [
        f"[DANGER] {r.get('name', '')}: {r.get('description', '')}"
        for r in risks
        if r.get("level") in ("danger", "critical")
    ]
    warn_warnings = [
        f"[WARN] {r.get('name', '')}: {r.get('description', '')}"
        for r in risks
        if r.get("level") == "warn"
    ]

    return SecurityReport(
        token_address    = token_address,
        is_mintable      = is_mintable,
        is_lp_locked     = lp_locked,
        is_honeypot      = is_honeypot,
        is_verified      = is_verified,
        top10_holder_pct = top10_pct,
        owner_renounced  = owner_renounced,
        freeze_authority = freeze_auth,
        warnings         = (danger_warnings + warn_warnings)[:10],
        raw_data         = data,
    )


# ---------------------------------------------------------------------------
# Calcul du score de sécurité (0–100)
# ---------------------------------------------------------------------------

def _calculate_score(report: SecurityReport) -> int:
    score = 100

    if report.is_mintable:
        score -= _PENALTY["is_mintable"]

    if report.is_honeypot:
        score -= _PENALTY["is_honeypot"]

    if not report.is_lp_locked:
        score -= _PENALTY["lp_not_locked"]

    if not report.is_verified:
        score -= _PENALTY["not_verified"]

    if report.freeze_authority:
        score -= _PENALTY["freeze_authority"]

    if not report.owner_renounced:
        score -= _PENALTY["owner_not_renounced"]

    # Pénalité concentration holders : par tranche de 10 % au-dessus du seuil
    excess = max(0.0, report.top10_holder_pct - SEC.max_top10_holder_pct)
    score -= int(excess / 10) * _PENALTY["top10_per_10pct"]

    # Pénalités des warnings RugCheck
    danger_count = sum(1 for w in report.warnings if w.startswith("[DANGER]"))
    warn_count   = sum(1 for w in report.warnings if w.startswith("[WARN]"))
    extra_warns  = max(0, warn_count - 2)   # les 2 premiers warns tolérés

    score -= danger_count * _PENALTY["danger_warning"]
    score -= extra_warns  * _PENALTY["warn_warning"]

    return max(0, min(100, score))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _any_keyword_match(texts: list[str], keywords: tuple[str, ...]) -> bool:
    return any(kw in text for text in texts for kw in keywords)


def _worst_case_report(token_address: str) -> SecurityReport:
    """Rapport conservateur quand RugCheck est inaccessible."""
    return SecurityReport(
        token_address    = token_address,
        is_mintable      = True,
        is_lp_locked     = False,
        is_honeypot      = True,
        is_verified      = False,
        top10_holder_pct = 100.0,
        owner_renounced  = False,
        freeze_authority = True,
        warnings         = ["[DANGER] API RugCheck inaccessible — worst-case appliqué"],
    )
