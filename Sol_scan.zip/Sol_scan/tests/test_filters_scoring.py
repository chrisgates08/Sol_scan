"""
=============================================================================
 Unit Tests — Filters & Scoring
=============================================================================
 Run with: pytest tests/ -v
=============================================================================
"""

import pytest
from utils.models import TokenPair, SecurityReport, Strategy
from filters.strategies import (
    apply_early_micro_cap_filter,
    apply_mid_cap_momentum_filter,
    classify_pair,
)
from scoring.engine import score_token, passes_signal_threshold


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_emc_pair(**overrides) -> TokenPair:
    """A pair that passes Early Micro-Cap filters by default."""
    defaults = dict(
        pair_address      = "PAIR123",
        base_token_addr   = "TOKEN123",
        base_token_name   = "TestCoin",
        base_token_symbol = "TEST",
        chain_id          = "solana",
        dex_id            = "raydium",
        price_usd         = 0.000025,
        price_change_1h   = 15.0,
        price_change_6h   = 40.0,
        price_change_24h  = 80.0,
        liquidity_usd     = 20_000.0,
        market_cap        = 60_000.0,
        volume_24h        = 80_000.0,
        txns_1h_buys      = 40,
        txns_1h_sells     = 15,
        txns_24h_buys     = 80,
        txns_24h_sells    = 30,
        pair_age_hours    = 6.0,
        has_profile       = True,
        dex_url           = "https://dexscreener.com/solana/PAIR123",
    )
    defaults.update(overrides)
    return TokenPair(**defaults)


def _make_mcm_pair(**overrides) -> TokenPair:
    """A pair that passes Mid-Cap Momentum filters by default."""
    defaults = dict(
        pair_address      = "PAIR456",
        base_token_addr   = "TOKEN456",
        base_token_name   = "MidToken",
        base_token_symbol = "MID",
        chain_id          = "solana",
        dex_id            = "orca",
        price_usd         = 0.005,
        price_change_1h   = 8.0,
        price_change_6h   = 15.0,
        price_change_24h  = 30.0,
        liquidity_usd     = 100_000.0,
        market_cap        = 1_500_000.0,
        volume_24h        = 500_000.0,
        txns_1h_buys      = 150,
        txns_1h_sells     = 80,
        txns_24h_buys     = 700,
        txns_24h_sells    = 400,
        pair_age_hours    = 72.0,
        has_profile       = True,
        dex_url           = "https://dexscreener.com/solana/PAIR456",
    )
    defaults.update(overrides)
    return TokenPair(**defaults)


def _make_good_security(addr: str = "TOKEN123") -> SecurityReport:
    return SecurityReport(
        token_address    = addr,
        is_mintable      = False,
        is_lp_locked     = True,
        is_honeypot      = False,
        is_verified      = True,
        top10_holder_pct = 18.0,
        owner_renounced  = True,
        freeze_authority = False,
        warnings         = [],
        security_score   = 90,
    )


def _make_bad_security(addr: str = "TOKEN123") -> SecurityReport:
    return SecurityReport(
        token_address    = addr,
        is_mintable      = True,
        is_lp_locked     = False,
        is_honeypot      = True,
        is_verified      = False,
        top10_holder_pct = 75.0,
        owner_renounced  = False,
        freeze_authority = True,
        warnings         = ["Mint active", "LP unlocked", "Honeypot detected"],
        security_score   = 0,
    )


# ---------------------------------------------------------------------------
# Filter tests — Early Micro-Cap
# ---------------------------------------------------------------------------

class TestEarlyMicroCapFilter:

    def test_valid_pair_passes(self):
        pair = _make_emc_pair()
        passed, reason = apply_early_micro_cap_filter(pair)
        assert passed, f"Should pass but got: {reason}"

    def test_wrong_chain_rejected(self):
        pair = _make_emc_pair(chain_id="ethereum")
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "chain" in reason

    def test_too_old_rejected(self):
        pair = _make_emc_pair(pair_age_hours=60.0)
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "old" in reason

    def test_too_young_no_age_rejected(self):
        pair = _make_emc_pair(pair_age_hours=0.0)
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed

    def test_low_liquidity_rejected(self):
        pair = _make_emc_pair(liquidity_usd=1_000.0)
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "liquidity" in reason

    def test_fdv_too_high_rejected(self):
        pair = _make_emc_pair(market_cap=500_000.0)
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "FDV" in reason

    def test_low_volume_rejected(self):
        pair = _make_emc_pair(volume_24h=5_000.0)
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "volume" in reason

    def test_low_txns_rejected(self):
        pair = _make_emc_pair(
            txns_1h_buys=5, txns_1h_sells=3,
            txns_24h_buys=30, txns_24h_sells=20,
        )
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "activity" in reason

    def test_no_profile_rejected_when_required(self):
        pair = _make_emc_pair(has_profile=False)
        passed, reason = apply_early_micro_cap_filter(pair)
        assert not passed
        assert "profile" in reason

    def test_high_1h_txns_satisfies_requirement(self):
        """≥50 tx/1h should satisfy even if 24h is below threshold."""
        pair = _make_emc_pair(
            txns_1h_buys=40, txns_1h_sells=15,   # 55 total ≥ 50
            txns_24h_buys=20, txns_24h_sells=10,  # 30 < 100 (24h threshold)
        )
        passed, reason = apply_early_micro_cap_filter(pair)
        assert passed, f"Should pass on 1h txns: {reason}"


# ---------------------------------------------------------------------------
# Filter tests — Mid-Cap Momentum
# ---------------------------------------------------------------------------

class TestMidCapMomentumFilter:

    def test_valid_pair_passes(self):
        pair = _make_mcm_pair()
        passed, reason = apply_mid_cap_momentum_filter(pair)
        assert passed, f"Should pass but got: {reason}"

    def test_low_momentum_rejected(self):
        pair = _make_mcm_pair(price_change_1h=2.0, price_change_6h=5.0)
        passed, reason = apply_mid_cap_momentum_filter(pair)
        assert not passed
        assert "momentum" in reason

    def test_insufficient_txns_rejected(self):
        pair = _make_mcm_pair(txns_24h_buys=300, txns_24h_sells=200)
        passed, reason = apply_mid_cap_momentum_filter(pair)
        assert not passed
        assert "tx count" in reason


# ---------------------------------------------------------------------------
# Classify (both strategies)
# ---------------------------------------------------------------------------

class TestClassify:

    def test_emc_wins_when_young(self):
        pair = _make_emc_pair()
        passed, strategy_name = classify_pair(pair)
        assert passed
        assert pair.strategy == Strategy.EARLY_MICRO_CAP

    def test_mcm_wins_for_mid_cap(self):
        pair = _make_mcm_pair()
        passed, strategy_name = classify_pair(pair)
        assert passed
        assert pair.strategy == Strategy.MID_CAP_MOMENTUM

    def test_rejected_pair(self):
        pair = _make_emc_pair(chain_id="ethereum", liquidity_usd=1_000)
        passed, reason = classify_pair(pair)
        assert not passed


# ---------------------------------------------------------------------------
# Scoring tests
# ---------------------------------------------------------------------------

class TestScoring:

    def test_high_quality_token_scores_above_threshold(self):
        pair = _make_emc_pair()
        pair.strategy = Strategy.EARLY_MICRO_CAP
        sec  = _make_good_security()
        token = score_token(pair, sec)
        assert token.signal_score >= 60, f"Score too low: {token.signal_score}"

    def test_risky_token_scores_low(self):
        pair = _make_emc_pair(
            price_change_1h  = -20.0,
            price_change_6h  = -30.0,
            volume_24h       = 5_000.0,
            txns_1h_buys     = 2,
            txns_1h_sells    = 8,
        )
        pair.strategy = Strategy.EARLY_MICRO_CAP
        sec  = _make_bad_security()
        token = score_token(pair, sec)
        assert token.signal_score < 60, f"Risky token scored too high: {token.signal_score}"

    def test_take_profit_targets_correct(self):
        pair = _make_emc_pair(price_usd=0.001)
        pair.strategy = Strategy.EARLY_MICRO_CAP
        sec  = _make_good_security()
        token = score_token(pair, sec)
        assert abs(token.tp1_usd - 0.002) < 1e-9, "TP1 should be 2x entry"
        assert abs(token.tp2_usd - 0.003) < 1e-9, "TP2 should be 3x entry"
        assert abs(token.tp3_usd - 0.004) < 1e-9, "TP3 should be 4x entry"

    def test_passes_signal_threshold(self):
        pair = _make_emc_pair()
        pair.strategy = Strategy.EARLY_MICRO_CAP
        sec  = _make_good_security()
        token = score_token(pair, sec)
        # We can't guarantee ≥80 without mocking, but we check the function works
        result = passes_signal_threshold(token)
        assert isinstance(result, bool)

    def test_breakdown_keys_present(self):
        pair = _make_emc_pair()
        pair.strategy = Strategy.EARLY_MICRO_CAP
        sec  = _make_good_security()
        token = score_token(pair, sec)
        expected_keys = {"liquidity", "volume", "transactions", "distribution", "momentum", "age", "security"}
        assert expected_keys.issubset(set(token.score_breakdown.keys()))

    def test_score_clamped_0_to_100(self):
        pair = _make_emc_pair(
            pair_age_hours   = 0.5,
            price_change_1h  = 500.0,
            price_change_6h  = 500.0,
            volume_24h       = 10_000_000.0,
            txns_1h_buys     = 10_000,
            txns_24h_buys    = 50_000,
        )
        pair.strategy = Strategy.EARLY_MICRO_CAP
        sec = _make_good_security()
        token = score_token(pair, sec)
        assert 0 <= token.signal_score <= 100
