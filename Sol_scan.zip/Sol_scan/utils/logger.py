"""
Centralised logging setup.
Call setup_logging() once in main.py, then use get_logger(__name__) everywhere.
"""

import logging
import sys
from logging.handlers import RotatingFileHandler

from config.settings import LOG_LEVEL, LOG_FILE


def setup_logging() -> None:
    """Configure root logger with console + rotating file handler."""
    numeric_level = getattr(logging, LOG_LEVEL.upper(), logging.INFO)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(numeric_level)

    # Console
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    root.addHandler(ch)

    # Rotating file (10 MB × 5)
    fh = RotatingFileHandler(LOG_FILE, maxBytes=10 * 1024 * 1024, backupCount=5)
    fh.setFormatter(fmt)
    root.addHandler(fh)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
