"""
=============================================================================
 Pipeline Orchestrator
=============================================================================
 Ties all modules together:
   1. Fetch pairs from DexScreener
   2. Strategy filter (EMC / MCM)
   3. Deduplication check
   4. Security analysis (async, concurrent)
   5. Security gate
   6. Signal scoring
   7. Score threshold gate
   8. Telegram alert

 Concurrency model:
   • Security checks are I/O bound → run in asyncio.gather with semaphore
   • Semaphore limits simultaneous API calls to avoid rate-limiting
=============================================================================
"""

from __future__ import annotations

import asyncio
import time
from typing import List, Tuple

from scanner      import fetch_new_solana_pairs
from filters      import classify_pair
from security     import analyse_token, is_safe_enough
from scoring      import score_token, passes_signal_threshold
from telegram     import send_alert
from data         import get_store
from utils.models import TokenPair, ScoredToken
from utils.logger import get_logger
from config       import MAX_CONCURRENT_REQUESTS, MIN_SIGNAL_SCORE

log = get_logger(__name__)

_security_semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)


# ---------------------------------------------------------------------------
# Single scan cycle
# ---------------------------------------------------------------------------

async def run_scan_cycle() -> Tuple[int, int, int, int]:
    """
    Execute one full scan cycle.
    Returns (fetched, filtered, passed_security, alerted) counts.
    """
    cycle_start = time.monotonic()
    store       = await get_store()

    # ── 1. Fetch ──────────────────────────────────────────────────────────
    pairs: List[TokenPair] = await fetch_new_solana_pairs()
    n_fetched = len(pairs)
    log.info("▶ Scan cycle: %d pairs fetched", n_fetched)

    # ── 2. Strategy filter ────────────────────────────────────────────────
    qualified: List[TokenPair] = []
    for pair in pairs:
        passed, reason = classify_pair(pair)
        if passed:
            qualified.append(pair)

    n_filtered = len(qualified)
    log.info("  ├─ After strategy filter: %d pairs", n_filtered)

    # ── 3. Deduplication ──────────────────────────────────────────────────
    new_pairs: List[TokenPair] = []
    for pair in qualified:
        key = pair.base_token_addr or pair.pair_address
        if not await store.is_seen(key):
            new_pairs.append(pair)

    log.info("  ├─ After dedup: %d new pairs", len(new_pairs))

    if not new_pairs:
        elapsed = time.monotonic() - cycle_start
        log.info("  └─ No new tokens this cycle. (%.2fs)", elapsed)
        return n_fetched, n_filtered, 0, 0

    # ── 4. Security analysis (concurrent) ─────────────────────────────────
    security_tasks = [
        _safe_analyse(pair) for pair in new_pairs
    ]
    analysed: List[Tuple[TokenPair, object]] = await asyncio.gather(*security_tasks)

    # ── 5. Security gate ──────────────────────────────────────────────────
    secure_pairs = [
        (pair, sec)
        for pair, sec in analysed
        if sec is not None and is_safe_enough(sec)
    ]
    n_secure = len(secure_pairs)
    log.info("  ├─ After security gate: %d pairs", n_secure)

    # ── 6 & 7. Score + threshold gate ─────────────────────────────────────
    alerts: List[ScoredToken] = []
    for pair, sec in secure_pairs:
        scored = score_token(pair, sec)
        if passes_signal_threshold(scored):
            alerts.append(scored)

    log.info("  ├─ After score threshold (≥%d): %d alerts", MIN_SIGNAL_SCORE, len(alerts))

    # ── 8. Send alerts + mark seen ────────────────────────────────────────
    n_alerted = 0
    for token in alerts:
        key = token.pair.base_token_addr or token.pair.pair_address
        sent = await send_alert(token)
        if sent:
            await store.mark_seen(key)
            n_alerted += 1
            # Throttle: 1 alert / 3s to respect Telegram rate limits
            await asyncio.sleep(3)
        else:
            log.warning("Alert send failed for %s — NOT marking as seen", token.pair.base_token_symbol)

    # Also mark seen tokens that passed security but didn't make score threshold
    # so we don't re-analyse them every cycle (expensive API calls)
    for pair, sec in secure_pairs:
        key = pair.base_token_addr or pair.pair_address
        if not await store.is_seen(key):
            await store.mark_seen(key)

    elapsed = time.monotonic() - cycle_start
    log.info(
        "  └─ Cycle complete: %d fetched → %d filtered → %d secure → %d alerted (%.2fs)",
        n_fetched, n_filtered, n_secure, n_alerted, elapsed,
    )
    return n_fetched, n_filtered, n_secure, n_alerted


# ---------------------------------------------------------------------------
# Concurrent security analysis with semaphore
# ---------------------------------------------------------------------------

async def _safe_analyse(pair: TokenPair):
    """Wrap security analysis in semaphore + exception guard."""
    async with _security_semaphore:
        try:
            sec = await analyse_token(pair.base_token_addr)
            return pair, sec
        except Exception as exc:
            log.warning(
                "Security analysis error for %s: %s",
                pair.base_token_addr[:12], exc
            )
            return pair, None
