"""
=============================================================================
 Telegram Alert System
=============================================================================
 Formats ScoredToken objects into rich HTML Telegram messages and sends
 them via the Bot API using aiohttp (no python-telegram-bot dependency).

 Message design: information-dense but scannable.
 Uses HTML parse_mode (safer than Markdown for dynamic content).
=============================================================================
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Optional

from config.settings import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, MIN_SIGNAL_SCORE
from utils.http_client import fetch_post_json
from utils.logger import get_logger
from utils.models import ScoredToken, Strategy

log = get_logger(__name__)

_TG_API = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"
_SEND_MESSAGE_URL = f"{_TG_API}/sendMessage"

# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

async def send_alert(token: ScoredToken) -> bool:
    """
    Format and dispatch a Telegram alert.
    Returns True on success, False on failure.
    """
    message = _format_alert(token)
    success = await _send(message)
    if success:
        log.info(
            "✅ Alert sent: %s (%s) score=%d",
            token.pair.base_token_symbol,
            token.pair.base_token_addr[:12],
            token.signal_score,
        )
    else:
        log.error(
            "❌ Failed to send alert for %s", token.pair.base_token_symbol
        )
    return success


async def send_startup_message() -> None:
    """Notify the channel that the bot has started."""
    now = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    text = (
        "🤖 <b>Solana Alpha Bot — ONLINE</b>\n\n"
        f"📅 Started: <code>{now}</code>\n"
        "🔍 Scanning DexScreener every 90s\n"
        "🛡 Security: RugCheck + GoPlus\n"
        "🎯 Min signal score: <b>" + str(MIN_SIGNAL_SCORE) + " / 100</b>\n\n"
        "<i>Only high-quality signals will be posted. No spam.</i>"
    )
    await _send(text)


async def send_error_notification(error_msg: str) -> None:
    """Relay critical bot errors to the channel for visibility."""
    text = f"⚠️ <b>Bot Error</b>\n<code>{_escape(error_msg[:500])}</code>"
    await _send(text)


# ---------------------------------------------------------------------------
# Message formatter
# ---------------------------------------------------------------------------

def _format_alert(token: ScoredToken) -> str:
    pair     = token.pair
    sec      = token.security
    score    = token.signal_score
    strategy = pair.strategy

    # ── Header ────────────────────────────────────────────────────────────
    strategy_emoji = "🧪" if strategy == Strategy.EARLY_MICRO_CAP else "📈"
    strategy_label = strategy.value if strategy else "🔎 Signal"

    score_bar  = _score_bar(score)
    age_str    = _fmt_age(pair.pair_age_hours)

    # ── Security badge ─────────────────────────────────────────────────────
    sec_score   = sec.security_score
    sec_badge   = _security_badge(sec_score)

    # ── Transaction totals ─────────────────────────────────────────────────
    txns_1h  = pair.txns_1h_buys  + pair.txns_1h_sells
    txns_24h = pair.txns_24h_buys + pair.txns_24h_sells
    buy_pct  = (
        int(pair.txns_1h_buys / txns_1h * 100)
        if txns_1h > 0 else 0
    )

    # ── Price momentum ─────────────────────────────────────────────────────
    def _pct(v: float) -> str:
        arrow = "🟢" if v >= 0 else "🔴"
        sign  = "+" if v >= 0 else ""
        return f"{arrow} {sign}{v:.1f}%"

    # ── Entry / TP ─────────────────────────────────────────────────────────
    entry = token.entry_price_usd
    tp1   = token.tp1_usd
    tp2   = token.tp2_usd
    tp3   = token.tp3_usd

    def _price(p: float) -> str:
        if p >= 1:           return f"${p:,.4f}"
        if p >= 0.0001:      return f"${p:.6f}"
        return f"${p:.10f}"

    # ── Holder concentration ───────────────────────────────────────────────
    top10_str  = f"{sec.top10_holder_pct:.1f}%"
    top10_risk = "⚠️ High" if sec.top10_holder_pct > 25 else "✅ Normal"

    # ── Warning blurb ──────────────────────────────────────────────────────
    warnings_block = ""
    if sec.warnings:
        w_lines = "\n".join(f"  • {_escape(w[:80])}" for w in sec.warnings[:3])
        warnings_block = f"\n⚠️ <b>Warnings:</b>\n{w_lines}\n"

    # ── Volume/Liq ratio ──────────────────────────────────────────────────
    vol_liq_ratio = (
        f"{pair.volume_24h / pair.liquidity_usd:.1f}x"
        if pair.liquidity_usd > 0 else "N/A"
    )

    # ── Score breakdown ───────────────────────────────────────────────────
    bd = token.score_breakdown
    breakdown_str = (
        f"  Liquidity {bd.get('liquidity',0):.0f}  "
        f"Volume {bd.get('volume',0):.0f}  "
        f"TXNs {bd.get('transactions',0):.0f}\n"
        f"  Momentum {bd.get('momentum',0):.0f}  "
        f"Age {bd.get('age',0):.0f}  "
        f"Security {bd.get('security',0):.0f}"
    )

    # ── Assemble ──────────────────────────────────────────────────────────
    msg = (
        f"{strategy_emoji} <b>{strategy_label}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"

        f"💎 <b>{_escape(pair.base_token_name)}</b>  "
        f"<code>${_escape(pair.base_token_symbol)}</code>\n\n"

        f"📋 <b>Contract:</b>\n"
        f"<code>{pair.base_token_addr}</code>\n\n"

        f"━━━━━━━ 📊 MARKET DATA ━━━━━━━\n"
        f"💰 Price:        <b>{_price(pair.price_usd)}</b>\n"
        f"📦 Market Cap:   <b>${_fmt_num(pair.market_cap)}</b>\n"
        f"💧 Liquidity:    <b>${_fmt_num(pair.liquidity_usd)}</b>\n"
        f"📈 Vol (24h):    <b>${_fmt_num(pair.volume_24h)}</b>  "
        f"<i>(Vol/Liq: {vol_liq_ratio})</i>\n"
        f"⏱ Age:          <b>{age_str}</b>\n\n"

        f"━━━━━━━ 🕹 PRICE ACTION ━━━━━━\n"
        f"1h:  {_pct(pair.price_change_1h)}\n"
        f"6h:  {_pct(pair.price_change_6h)}\n"
        f"24h: {_pct(pair.price_change_24h)}\n\n"

        f"━━━━━━━ 🔁 TRANSACTIONS ━━━━━━\n"
        f"Last 1h:   <b>{txns_1h:,}</b>  "
        f"({pair.txns_1h_buys:,}🟢 / {pair.txns_1h_sells:,}🔴)  "
        f"Buy: {buy_pct}%\n"
        f"Last 24h:  <b>{txns_24h:,}</b>  "
        f"({pair.txns_24h_buys:,}🟢 / {pair.txns_24h_sells:,}🔴)\n\n"

        f"━━━━━━━ 🛡 SECURITY (RugCheck) ━\n"
        + (
            "⚠️ <i>RugCheck indisponible — données estimées</i>\n"
            if sec.raw_data.get("_api_failed") else ""
        ) +
        f"Score:       {sec_badge}  <b>{sec_score}/100</b>\n"
        f"Mint:        {'🔴 Active' if sec.is_mintable else '✅ Disabled'}\n"
        f"LP:          {'✅ Locked/Burned' if sec.is_lp_locked else '⚠️ Unlocked'}\n"
        f"Honeypot:    {'🔴 YES' if sec.is_honeypot else '✅ No'}\n"
        f"Verified:    {'✅ Yes' if sec.is_verified else '⚠️ No'}\n"
        f"Top 10 Hold: <b>{top10_str}</b>  {top10_risk}\n"
        f"Owner:       {'✅ Renounced' if sec.owner_renounced else '⚠️ Active'}\n"
        f"{warnings_block}\n"

        f"━━━━━━━ 🎯 SIGNAL SCORE ━━━━━\n"
        f"{score_bar}  <b>{score}/100</b>\n"
        f"<code>{breakdown_str}</code>\n\n"

        f"━━━━━━━ 💸 TARGETS ━━━━━━━━━━\n"
        f"🔵 Entry:   <b>{_price(entry)}</b>\n"
        f"🟡 TP1 +100%: <b>{_price(tp1)}</b>\n"
        f"🟠 TP2 +200%: <b>{_price(tp2)}</b>\n"
        f"🔴 TP3 +300%: <b>{_price(tp3)}</b>\n\n"

        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔗 <a href=\"{pair.dex_url}\">DexScreener Chart</a>\n"
        f"🔗 <a href=\"https://solscan.io/token/{pair.base_token_addr}\">Solscan</a>\n"
        f"🔗 <a href=\"https://rugcheck.xyz/tokens/{pair.base_token_addr}\">RugCheck</a>\n\n"
        f"<i>⚡ DYOR. Not financial advice. High-risk asset.</i>"
    )

    return msg


# ---------------------------------------------------------------------------
# Telegram API sender
# ---------------------------------------------------------------------------

async def _send(text: str, chat_id: str = TELEGRAM_CHAT_ID) -> bool:
    payload = {
        "chat_id":                  chat_id,
        "text":                     text,
        "parse_mode":               "HTML",
        "disable_web_page_preview": True,
    }
    result = await fetch_post_json(_SEND_MESSAGE_URL, payload)
    if result and result.get("ok"):
        return True
    log.error("Telegram API error: %s", result)
    return False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt_num(n: float) -> str:
    """Format large numbers as 1.2K / 3.4M etc."""
    if n >= 1_000_000:  return f"{n/1_000_000:.2f}M"
    if n >= 1_000:      return f"{n/1_000:.1f}K"
    return f"{n:.0f}"


def _fmt_age(hours: float) -> str:
    if hours < 1:      return f"{int(hours*60)}m"
    if hours < 24:     return f"{hours:.1f}h"
    return f"{hours/24:.1f}d"


def _score_bar(score: int, width: int = 10) -> str:
    """Visual bar: ██████░░░░"""
    filled = int(score / 100 * width)
    return "█" * filled + "░" * (width - filled)


def _security_badge(score: int) -> str:
    if score >= MIN_SIGNAL_SCORE: return "🟢"
    if score >= 60: return "🟡"
    if score >= 40: return "🟠"
    return "🔴"


def _escape(text: str) -> str:
    """Minimal HTML escaping for Telegram HTML mode."""
    return (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
    )
